# exp_files/export_all.ps1
# Exports filtered files (paths + minified code) into _export.txt

# -------- Settings --------
$excludeFolders    = @('vendor', '.vscode', 'var', 'logs', 'tests', 'node_modules', '.git', 'core', 'database', 'exp_files', 'routes', 'storage','public')
$excludeFiles      = @('.env', 'export_all.ps1', '_export.txt' ,'.gitignore', 'composer.lock', 'package-lock.json')
$includeExtensions = @('.php')
$outputFile        = '_exportAPP.txt'
# --------------------------

$ErrorActionPreference = 'Stop'

# Go one level up from script location
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$root      = Split-Path -Parent $scriptDir

Write-Host "Root: $root"
Write-Host "Excluding folders: $($excludeFolders -join ', ')"
Write-Host "Including extensions: $(if($includeExtensions.Count){$includeExtensions -join ', '}else{'<all>'})"
Write-Host "Scanning...`n"


# Remove existing output file if it exists
if (Test-Path $outputFile) {
    try {
        Remove-Item $outputFile -Force
        Write-Host "Removed existing $outputFile"
    }
    catch {
        Write-Host "Warning: Could not remove existing $outputFile. Please close any programs that may have it open and try again." -ForegroundColor Yellow
        exit 1
    }
}

# Normalize for case-insensitive compare
$excludeSet = $excludeFolders | ForEach-Object { $_.ToLowerInvariant() }
$extSet     = $includeExtensions | ForEach-Object {
    if ($_ -notlike '.*') { ".$_" } else { $_ }
} | ForEach-Object { $_.ToLowerInvariant() }

# Helper: Skip recursion into excluded folders
function Get-Files {
    param ([string]$path)
    foreach ($item in Get-ChildItem -Path $path -Force -ErrorAction SilentlyContinue) {
        if ($item.PSIsContainer) {
            if ($excludeSet -contains $item.Name.ToLowerInvariant()) {
                continue
            }
            foreach ($child in Get-Files -path $item.FullName) { $child }
        }
        else {
            $fileName = $item.Name.ToLowerInvariant()
            if ($excludeFiles -contains $fileName) { continue }

            if ($extSet.Count -eq 0 -or $extSet -contains $item.Extension.ToLowerInvariant()) {
                $item
            }
        }
    }
}

# Fetch files without entering excluded dirs
$files = Get-Files -path $root | Sort-Object FullName
$total = $files.Count

if ($total -eq 0) {
    "No matching files found." | Out-File -Encoding UTF8 $outputFile
    Write-Host "Done. No files found."
    exit
}

$relPaths = $files | ForEach-Object {
    $_.FullName.Substring($root.Length).TrimStart('\','/')
}

$first = $relPaths[0]
$last  = $relPaths[-1]

# Build content in memory first
$outputContent = @()
$outputContent += "# Export summary"
$outputContent += "Date: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss K')"
$outputContent += "Root: $root"
$outputContent += "Excluded folders: $($excludeFolders -join ', ')"
$outputContent += "Included extensions: $(if($extSet.Count){$extSet -join ', '}else{'<all>'})"
$outputContent += "Matched: $total"
$outputContent += "First: $first"
$outputContent += "Last:  $last"
$outputContent += "Minified: $first ... $last"
$outputContent += ""

# Process each file and add to content array
$counter = 0
foreach ($file in $files) {
    $counter++
    Write-Progress -Activity "Processing files" -Status "$counter of $total" -PercentComplete (($counter / $total) * 100)

    $relPath = $file.FullName.Substring($root.Length).TrimStart('\','/')
    $outputContent += ""
    $outputContent += "--- $relPath ---"

    try {
        $content = Get-Content $file.FullName -Raw -ErrorAction Stop
        if ($content) {
            # Minify: remove extra blank lines and collapse spaces
            $minified = $content -replace '\s+', ' ' -replace '(\r?\n)+', ' '
            $outputContent += $minified
        } else {
            $outputContent += "[Empty file]"
        }
    }
    catch {
        $outputContent += "[Error reading file: $($_.Exception.Message)]"
    }
}

# Write all content at once to avoid file handle issues
try {
    $outputContent | Out-File -FilePath $outputFile -Encoding UTF8 -Force
    Write-Progress -Activity "Processing files" -Completed
    Write-Host "`nExport complete: $total files with minified content written to $outputFile"
}
catch {
    Write-Host "Error writing to output file: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Please ensure $outputFile is not open in another application." -ForegroundColor Yellow
    exit 1
}