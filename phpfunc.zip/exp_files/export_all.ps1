# export_all.ps1
# Exports filtered files (paths + minified code) into _export[_<filter>].txt

param (
    [Alias("f")]
    [string]$file_name = ""
)

# -------- Settings --------
$excludeFolders    = @('vendor', '.vscode', 'var', 'logs', 'tests', 'node_modules', '.git', 'public/assets/css/')
$excludeFiles      = @('.env', 'export_all.ps1', '_export.txt' ,'.gitignore', 'composer.lock', 'package-lock.json')
$includeExtensions = @('.php', '.html', '.css', '.js', '.json')
# Dynamic output file name
$outputFile        = "_export$($(if($file_name -ne ''){'_' + $file_name}) ).txt".Trim()
# --------------------------

$ErrorActionPreference = 'Stop'
$root = (Get-Location).Path
Write-Host "Root: $root"
if ($file_name) { Write-Host "Filtering files containing: $file_name" }
Write-Host "Excluding folders: $($excludeFolders -join ', ')"
Write-Host "Including extensions: $(if($includeExtensions.Count){$includeExtensions -join ', '}else{'<all>'})"
Write-Host "Scanning...`n"

# Remove existing output file if it exists
if (Test-Path $outputFile) {
    try {
        Remove-Item $outputFile -Force
        Write-Host "Removed existing $outputFile"
    }
    catch {
        Write-Host "Warning: Could not remove existing $outputFile. Please close any programs that may have it open and try again." -ForegroundColor Yellow
        exit 1
    }
}

# -------- Exclude Folders → Regex Patterns --------
$excludePatterns = @()
foreach ($ex in $excludeFolders) {
    $exNorm = $ex.Trim().Replace('\','/').Trim('/')
    if ($exNorm -eq '') { continue }
    if ($exNorm -match '[*?]') {
        $escaped = [regex]::Escape($exNorm) -replace '\\\*','.*' -replace '\\\?','.'
        $excludePatterns += "^$escaped($|/)"
    } else {
        $excludePatterns += "(^|/)" + [regex]::Escape($exNorm) + "($|/)"
    }
}

# -------- Exclude Files & Extensions --------
$excludeFilesLower = $excludeFiles | ForEach-Object { $_.ToLowerInvariant() }
$extSet = $includeExtensions | ForEach-Object {
    $e = $_.Trim()
    if ($e -notmatch '^\.') { ".$e" } else { $e }
} | ForEach-Object { $_.ToLowerInvariant() }

# -------- Recursive File Enumerator --------
function Get-Files {
    param ([string]$path)
    foreach ($item in Get-ChildItem -Path $path -Force -ErrorAction SilentlyContinue) {
        if ($item.PSIsContainer) {
            $relDir = $item.FullName.Substring($root.Length).TrimStart('\','/').Replace('\','/').Trim('/').ToLowerInvariant()
            $skip = $false
            foreach ($pat in $excludePatterns) {
                if ($relDir -match $pat) { $skip = $true; break }
            }
            if ($skip) { continue }
            foreach ($child in Get-Files -path $item.FullName) { $child }
        }
        else {
            $fileName = $item.Name.ToLowerInvariant()
            if ($excludeFilesLower -contains $fileName) { continue }
            if ($extSet.Count -eq 0 -or $extSet -contains $item.Extension.ToLowerInvariant()) {
                if ($file_name -eq "" -or $item.FullName -match $file_name) {
                    $item
                }
            }
        }
    }
}

# -------- Collect Files --------
$files = Get-Files -path $root | Sort-Object FullName
$total = $files.Count

if ($total -eq 0) {
    "No matching files found." | Out-File -Encoding UTF8 $outputFile
    Write-Host "Done. No files found."
    exit
}

$relPaths = $files | ForEach-Object {
    $_.FullName.Substring($root.Length).TrimStart('\','/')
}
$first = $relPaths[0]
$last  = $relPaths[-1]

# -------- Build Export --------
$outputContent = @()
$outputContent += "# Export summary"
$outputContent += "Date: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss K')"
$outputContent += "Root: $root"
$outputContent += "Filter: $(if($file_name){$file_name}else{'<none>'})"
$outputContent += "Excluded folders: $($excludeFolders -join ', ')"
$outputContent += "Included extensions: $(if($extSet.Count){$extSet -join ', '}else{'<all>'})"
$outputContent += "Matched: $total"
$outputContent += "First: $first"
$outputContent += "Last:  $last"
$outputContent += ""

$counter = 0
foreach ($file in $files) {
    $counter++
    Write-Progress -Activity "Processing files" -Status "$counter of $total" -PercentComplete (($counter / $total) * 100)
    $relPath = $file.FullName.Substring($root.Length).TrimStart('\','/')
    $outputContent += ""
    $outputContent += "--- $relPath ---"
    try {
        $content = Get-Content $file.FullName -Raw -ErrorAction Stop
        if ($content) {
            $minified = $content -replace '\s+', ' ' -replace '(\r?\n)+', ' '
            $outputContent += $minified
        } else {
            $outputContent += "[Empty file]"
        }
    }
    catch {
        $outputContent += "[Error reading file: $($_.Exception.Message)]"
    }
}

# -------- Write File --------
try {
    $outputContent | Out-File -FilePath $outputFile -Encoding UTF8 -Force
    Write-Progress -Activity "Processing files" -Completed
    Write-Host "`nExport complete: $total files written to $outputFile"
}
catch {
    Write-Host "Error writing to output file: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
