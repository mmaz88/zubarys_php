<?php // routes/auth.php

/**
 * Defines authentication-related routes for API and Web.
 */
declare(strict_types=1);

// API route group for authentication
group(['prefix' => 'api/auth'], function () {
    /**
     * Handles the login attempt.
     */
    post('/login', function () {
        require_once API_PATH . '/auth/LoginApi.php';
        return handle_login();
    });
});


/**
 * Handles the logout action for web users.
 * This is a POST route to prevent CSRF attacks on the logout functionality.
 */
post('/logout', function () {
    // Ensure a CSRF token is present and valid for logout
    if (isset($_POST['_csrf_token']) && verify_csrf($_POST['_csrf_token'])) {
        session_flush();
        return redirect('/login');
    }

    // If token is invalid, return an error
    return error('Invalid request.', 403);
});