<?php

/**
 * routes/api.php - API Routes
 *
 * Defines routes for the API.
 */

declare(strict_types=1);
