<?php /** * routes/web.php - Web Routes * * REFACTORED: Now uses a simple, direct call to the corrected view() helper. */

declare(strict_types=1);

// Redirect the root URL to the dashboard
get('/', function () {
    return redirect('/dashboard');
});

// --- Application Routes (Authenticated Area) ---

get('/dashboard', function () {
    return view('dashboard', [
        'title' => 'Dashboard',
        'page_title' => 'Dashboard Overview',
        'breadcrumbs' => [['text' => 'Home']],
    ], 'layout.main'); // Render 'dashboard' view inside the 'layout.main' layout
});




// --- Public Routes (Login, etc.) ---

get('/login', function () {
    // Render the 'login' view inside the 'layout.public' layout
    return view('login', ['title' => 'Sign In'], 'layout.public');
});