<?php /**
  * routes/user_routes.php - User Management Routes
  * REFACTORED: Routes now point to the new users/index.php and users/view.php structure.
  */
declare(strict_types=1);

// WEB ROUTE: Renders the main user management list page.
get('/users', function () {
    // Correctly points to app/views/system/users/index.php
    return view('system.users.index', [
        'title' => 'Users',
        'page_title' => 'Manage Users',
        'breadcrumbs' => [
            ['text' => 'Home', 'url' => '/dashboard'],
            ['text' => 'Core Systems'],
            ['text' => 'Users'],
        ],
    ], 'layout.main');
});

// WEB ROUTE: Renders the user detail/view page.
get('/users/{id}', function (string $id) {
    // Fetch user server-side to set page title and check for existence.
    $user = table('users')->where('id', '=', $id)->first();

    if (!$user) {
        // Render a 404 page if the user doesn't exist.
        return view('errors.404', ['title' => 'User Not Found'], 'layout.main');
    }

    // Correctly points to app/views/system/users/view.php
    return view('system.users.view', [
        'title' => 'View User: ' . h($user['name']),
        'page_title' => 'User Profile',
        'breadcrumbs' => [
            ['text' => 'Home', 'url' => '/dashboard'],
            ['text' => 'Users', 'url' => '/users'],
            ['text' => h($user['name'])], // Current page
        ],
        'user_id' => $id // Pass the ID to the view for the JS API call
    ], 'layout.main');
});


// API ROUTES: Grouped for user CRUD operations (Unchanged).
group(['prefix' => 'api/users', 'middleware' => ['CorsMiddleware', 'AuthMiddleware']], function () {
    get('/', function () {
        require_once API_PATH . '/system/UserApi.php';
        return handle_list_users();
    });

    post('/', function () {
        require_once API_PATH . '/system/UserApi.php';
        return handle_create_user();
    });

    get('/{id}', function (string $id) {
        require_once API_PATH . '/system/UserApi.php';
        return handle_get_user($id);
    });

    post('/{id}', function (string $id) {
        require_once API_PATH . '/system/UserApi.php';
        return handle_update_user($id);
    });

    post('/{id}/delete', function (string $id) {
        require_once API_PATH . '/system/UserApi.php';
        return handle_delete_user($id);
    });
});