<?php
/**
 * app/views/placeholder.php
 * A generic view to display content passed from the router.
 */
?>
<?= $page_content ?? '<p>No content has been set for this page.</p>' ?>