<?php
/**
 * app/views/system/tenants.php
 * View for managing tenants with the dynamic table component and modal.
 */

// --- 1. Dynamic Table Configuration ---
$table_config = [
    'columns' => [
        ['key' => 'name', 'title' => 'Name', 'sortable' => true],
        ['key' => 'domain', 'title' => 'Domain', 'sortable' => true],
        ['key' => 'status', 'title' => 'Status', 'sortable' => true, 'render' => 'statusBadge'],
        ['key' => 'created_at', 'title' => 'Created On', 'sortable' => true, 'render' => 'date'],
        ['key' => 'id', 'title' => 'Actions', 'sortable' => false, 'render' => 'actions']
    ],
    'dataSource' => ['url' => '/tenants'],
    'filters' => [
        [
            'key' => 'search',
            'label' => 'Search name or domain...',
            'type' => 'text',
            'width' => 'grow'
        ],
        [
            'key' => 'status',
            'label' => 'Statuses',
            'type' => 'select',
            'options' => ['active' => 'Active', 'suspended' => 'Suspended', 'disabled' => 'Disabled'],
            'width' => '200px'
        ]
    ],
    'filter_options' => ['size' => 'sm'],
    'features' => ['global_search' => true],
    'defaultSort' => ['column' => 'created_at', 'direction' => 'desc'],
    'emptyMessage' => 'No tenants found. Click "Create Tenant" to get started.'
];

$create_button = button('Create Tenant', [
    'variant' => 'primary',
    'icon' => 'add-outline',
    'attributes' => ['id' => 'create-tenant-btn']
]);

echo card([
    'header' => [
        'title' => 'All Tenants',
        'actions' => $create_button
    ],
    'body' => render_advanced_table('tenants-table', $table_config),
    'attributes' => ['class' => 'card-body-flush']
]);
?>

<!-- =================================================================
Tenant Create/Edit Modal
================================================================= -->
<div id="tenant-modal" class="modal-overlay hidden">
    <div class="modal-content">
        <form id="tenant-form" autocomplete="off">
            <div class="modal-header">
                <h3 id="modal-title" class="modal-title">Create New Tenant</h3>
                <?= icon_button('close-outline', ['attributes' => ['id' => 'close-modal-btn']]) ?>
            </div>
            <div class="modal-body">
                <div id="modal-errors"
                    class="hidden mb-4 p-3 bg-destructive/10 text-destructive border border-destructive/20 rounded-md text-sm">
                </div>

                <input type="hidden" id="tenant-id" name="id">

                <?= form_input('name', [
                    'label' => 'Tenant Name',
                    'required' => true,
                    'attributes' => ['id' => 'tenant-name']
                ]) ?>

                <?= form_input('domain', [
                    'label' => 'Domain',
                    'help_text' => 'Optional. e.g., acme.example.com',
                    'attributes' => ['id' => 'tenant-domain']
                ]) ?>

                <?= form_select('status', [
                    'label' => 'Status',
                    'required' => true,
                    'options' => [
                        'active' => 'Active',
                        'suspended' => 'Suspended',
                        'disabled' => 'Disabled'
                    ],
                    'selected' => 'active',
                    'attributes' => ['id' => 'tenant-status']
                ]) ?>
            </div>
            <div class="modal-footer">
                <button type="button" id="cancel-modal-btn" class="btn btn-secondary">Cancel</button>
                <?php
                echo button('Save Tenant', [
                    'type' => 'submit',
                    'variant' => 'primary',
                    'attributes' => ['id' => 'save-tenant-btn']
                ]);
                ?>
            </div>
        </form>
    </div>
</div>

<!-- Page-Specific JavaScript -->
<script>
    document.addEventListener('DOMContentLoaded', () => {
        // --- Custom Renderers for the Dynamic Table ---
        DynamicTable.addRenderer('statusBadge', (status) => {
            const lowerStatus = (status || '').toLowerCase();
            let colorClass = 'bg-gray-200 text-gray-800';
            if (lowerStatus === 'active') colorClass = 'bg-success/20 text-success';
            if (lowerStatus === 'suspended') colorClass = 'bg-warning/20 text-warning';
            if (lowerStatus === 'disabled') colorClass = 'bg-destructive/20 text-destructive';
            const text = App.escapeHTML(lowerStatus.charAt(0).toUpperCase() + lowerStatus.slice(1));
            return `<span class="px-2 py-1 text-xs font-medium rounded-full ${colorClass}">${text}</span>`;
        });

        DynamicTable.addRenderer('actions', (id) => {
            return `
            <div class="flex items-center justify-end">
                <button class="btn btn-ghost btn-sm btn-icon edit-btn" data-id="${id}" title="Edit Tenant"><ion-icon name="pencil-outline"></ion-icon></button>
                <button class="btn btn-ghost btn-sm btn-icon text-destructive delete-btn" data-id="${id}" title="Delete Tenant"><ion-icon name="trash-outline"></ion-icon></button>
            </div>`;
        });

        DynamicTable.initAll();

        const tenantsTable = document.getElementById('tenants-table')?.dynamicTableInstance;
        if (!tenantsTable) {
            console.error('Tenants table instance not found.');
            return;
        }

        // --- Element Selectors ---
        const get = (id) => document.getElementById(id);
        const modal = get('tenant-modal');
        const form = get('tenant-form');
        const saveBtn = get('save-tenant-btn');
        const errorContainer = get('modal-errors');
        let activeModalCloser = null; // To manage the ESC key listener

        // --- Modal Management ---
        const openModal = (mode = 'create', data = null) => {
            form.reset();
            get('tenant-id').value = '';
            errorContainer.classList.add('hidden');
            errorContainer.innerHTML = '';
            get('modal-title').textContent = mode === 'edit' ? 'Edit Tenant' : 'Create New Tenant';

            if (mode === 'edit' && data) {
                get('tenant-id').value = data.id;
                get('tenant-name').value = data.name;
                get('tenant-domain').value = data.domain || '';
                get('tenant-status').value = data.status;
            }

            modal.classList.remove('hidden');
            setTimeout(() => modal.classList.add('visible'), 10);

            // Add ESC key listener
            const handleEsc = (e) => {
                if (e.key === 'Escape') closeModal();
            };
            document.addEventListener('keydown', handleEsc);
            activeModalCloser = () => document.removeEventListener('keydown', handleEsc);
        };

        const closeModal = () => {
            modal.classList.remove('visible');
            setTimeout(() => modal.classList.add('hidden'), 200);
            if (activeModalCloser) activeModalCloser();
        };

        const displayFormErrors = (errors) => {
            errorContainer.innerHTML = `<ul>${Object.values(errors).map(e => `<li>${App.escapeHTML(e)}</li>`).join('')}</ul>`;
            errorContainer.classList.remove('hidden');
        };

        // --- Event Listeners ---
        get('create-tenant-btn').addEventListener('click', () => openModal('create'));
        modal.querySelectorAll('.modal-close, #cancel-modal-btn').forEach(el => el.addEventListener('click', closeModal));

        tenantsTable.element.addEventListener('click', async (e) => {
            const editBtn = e.target.closest('.edit-btn');
            if (editBtn) {
                try {
                    const result = await App.api(`tenants/${editBtn.dataset.id}`);
                    openModal('edit', result.data);
                } catch (error) {
                    App.notify.error(error.message || 'Failed to fetch tenant data.');
                }
            }

            const deleteBtn = e.target.closest('.delete-btn');
            if (deleteBtn) {
                try {
                    await App.confirm({ title: 'Delete Tenant?', message: 'This action cannot be undone.', confirmVariant: 'destructive' });
                    const result = await App.api(`tenants/${deleteBtn.dataset.id}/delete`, { method: 'POST' });
                    App.notify.success(result.message);
                    tenantsTable.refresh();
                } catch (error) {
                    if (error && error.message) App.notify.error(error.message);
                }
            }
        });

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            saveBtn.classList.add('btn-loading');
            saveBtn.disabled = true;
            const id = get('tenant-id').value;
            const endpoint = id ? `tenants/${id}` : 'tenants';

            try {
                const result = await App.api(endpoint, { method: 'POST', body: new FormData(form) });
                App.notify.success(result.message);
                closeModal();
                tenantsTable.refresh();
            } catch (error) {
                if (error.status === 422 && error.response.errors) {
                    displayFormErrors(error.response.errors);
                } else {
                    App.notify.error(error.message || 'An unexpected error occurred.');
                }
            } finally {
                saveBtn.classList.remove('btn-loading');
                saveBtn.disabled = false;
            }
        });
    });
</script>