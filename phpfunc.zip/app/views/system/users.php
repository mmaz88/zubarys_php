<?php /**
  * app/views/system/users.php
  * View for managing users with the dynamic table component and modal.
  */

// --- Dynamic Table Configuration ---
$table_config = [
    'columns' => [
        [
            'key' => 'name',
            'title' => 'User & Email',
            'sortable' => true,
            'filterable' => true, // Enable inline header filter for this column
            'filter_type' => 'text',
            'render' => 'userName'
        ],
        [
            'key' => 'tenant_name',
            'title' => 'Tenant',
            'sortable' => true,
            'filterable' => true, // Enable inline header filter for this column
            'filter_type' => 'text'
        ],
        [
            'key' => 'created_at',
            'title' => 'Created On',
            'sortable' => true,
            'render' => 'date'
        ],
        [
            'key' => 'id',
            'title' => 'Actions',
            'sortable' => false,
            'render' => 'actions',
            'align' => 'right'
        ]
    ],
    'dataSource' => ['url' => '/api/users'],
    // This defines the main filter bar above the table (for global search)
    'filters' => [
        ['key' => 'search', 'label' => 'Search name, email or tenant...', 'type' => 'text', 'width' => 'grow'],
    ],
    // This enables the new AG Grid-style filters in the table header
    'features' => [
        'inline_filters' => true,
        'pagination' => true
    ],
    'defaultSort' => ['column' => 'created_at', 'direction' => 'desc'],
    'emptyMessage' => 'No users found. Click "Create User" to get started.'
];

$create_button = button('Create User', [
    'variant' => 'primary',
    'icon' => 'add-outline',
    'attributes' => ['id' => 'create-user-btn']
]);

echo card([
    'header' => [
        'title' => 'All Users',
        'actions' => $create_button
    ],
    'body' => render_advanced_table('users-table', $table_config),
    'attributes' => ['class' => 'card-body-flush']
]);

?>
<!-- User Create/Edit Modal (remains unchanged) -->
<div id="user-modal" class="modal-overlay hidden">
    <div class="modal-content">
        <form id="user-form" autocomplete="off">
            <div class="modal-header">
                <h3 id="modal-title" class="modal-title">Create New User</h3>
                <?= icon_button('close-outline', ['attributes' => ['class' => 'modal-close']]) ?>
            </div>
            <div class="modal-body">
                <div id="modal-errors"
                    class="hidden mb-4 p-3 bg-destructive/10 text-destructive border border-destructive/20 rounded-md text-sm">
                </div>
                <input type="hidden" id="user-id" name="id">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <?= form_input('name', ['label' => 'Full Name', 'required' => true, 'attributes' => ['id' => 'user-name']]) ?>
                    <?= form_input('email', ['label' => 'Email Address', 'type' => 'email', 'required' => true, 'attributes' => ['id' => 'user-email']]) ?>
                </div>
                <?= form_input('password', ['label' => 'Password', 'type' => 'password', 'help_text' => 'Leave blank to keep current password.', 'attributes' => ['id' => 'user-password', 'autocomplete' => 'new-password']]) ?>
                <?php
                $tenants = table('tenants')->orderBy('name')->get();
                $tenant_options = array_column($tenants, 'name', 'id');
                echo form_select('tenant_id', [
                    'label' => 'Tenant',
                    'required' => true,
                    'options' => $tenant_options,
                    'placeholder' => 'Select a Tenant',
                    'attributes' => ['id' => 'user-tenant']
                ]);
                ?>
                <div class="mt-4">
                    <?= form_checkbox('is_tenant_admin', ['label' => 'Is Tenant Administrator?', 'attributes' => ['id' => 'user-is-admin']]) ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                <?= button('Save User', ['type' => 'submit', 'variant' => 'primary', 'attributes' => ['id' => 'save-user-btn']]); ?>
            </div>
        </form>
    </div>
</div>

<!-- Page-Specific JavaScript -->
<script>
    document.addEventListener('DOMContentLoaded', () => {
        // --- Custom Renderers ---
        DynamicTable.addRenderer('userName', (value, row) => {
            const name = App.escapeHTML(row.name);
            const email = App.escapeHTML(row.email);
            return `<div class="font-medium text-fg">${name}</div><div class="text-xs text-fg-muted">${email}</div>`;
        });

        DynamicTable.addRenderer('actions', (id) => {
            return `
            <div class="table-actions justify-end">
                <a href="/users/${id}" class="btn btn-ghost btn-sm btn-icon" title="View User"><ion-icon name="eye-outline"></ion-icon></a>
                <button class="btn btn-ghost btn-sm btn-icon edit-btn" data-id="${id}" title="Edit User"><ion-icon name="pencil-outline"></ion-icon></button>
                <button class="btn btn-ghost btn-sm btn-icon text-destructive delete-btn" data-id="${id}" title="Delete User"><ion-icon name="trash-outline"></ion-icon></button>
            </div>`;
        });

        DynamicTable.initAll();
        const usersTable = document.getElementById('users-table')?.dynamicTableInstance;
        if (!usersTable) return;

        // --- All Modal Logic (remains unchanged) ---
        const get = (id) => document.getElementById(id);
        const modal = get('user-modal');
        const form = get('user-form');
        // ... (The rest of your modal handling JavaScript remains exactly the same)
    });
</script>