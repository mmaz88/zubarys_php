<?php
/**
 * app/views/system/users/index.php
 * The main view for listing, searching, and managing all users.
 */

// --- 1. Dynamic Table Configuration ---
// This configuration array powers the entire table component.
// The 'key' for each column MUST match the column name whitelisted in the backend API.
$table_config = [
    'layout' => 'fixed', // Use 'fixed' for tables that should span the full width, or 'auto' for tables that size to their content.
    'columns' => [
        [
            'key' => 'users.name', // Fully qualified name for filtering/sorting
            'title' => 'User & Email',
            'sortable' => true,
            'filterable' => true,
            'filter_data_type' => 'text',
            'render' => 'userName'
        ],
        [
            'key' => 'tenant_name', // Fully qualified name for filtering/sorting
            'title' => 'Tenant',
            'sortable' => true,
            'filterable' => true,
            'filter_data_type' => 'text',
        ],
        [
            'key' => 'created_at', // Fully qualified name for filtering/sorting
            'title' => 'Created On',
            'sortable' => true,
            'filter_data_type' => 'date',
            'render' => 'date'
        ],
        [
            'key' => 'id',
            'title' => 'Actions',
            'sortable' => false,
            'render' => 'actions',
            'align' => 'right',
            'width' => '130px' // Set a fixed width for the actions column
        ]
    ],
    'dataSource' => ['url' => '/users'],
    // Main filter bar (global search)
    'filters' => [
        ['key' => 'search', 'label' => 'Search name, email or tenant...', 'type' => 'text', 'width' => 'grow'],
    ],
    // Enables the filter popups in the table header
    'features' => [
        'inline_filters' => true,
        'pagination' => true
    ],
    'defaultSort' => ['column' => 'users.created_at', 'direction' => 'desc'],
    'emptyMessage' => 'No users found. Click "Create User" to get started.'
];

// --- 2. Page Header Actions ---
$create_button = button('Create User', [
    'variant' => 'primary',
    'icon' => 'add-outline',
    'attributes' => ['id' => 'create-user-btn']
]);

// --- 3. Render Page Structure ---
// The main card that contains the entire table component.
echo card([
    'header' => [
        'title' => 'All Users',
        'actions' => $create_button
    ],
    'body' => render_advanced_table('users-table', $table_config),
    'attributes' => ['class' => 'card-body-flush'] // Removes padding to let the table fit flush.
]);
?>

<!-- =================================================================
     User Create/Edit Modal
     ================================================================= -->
<div id="user-modal" class="modal-overlay hidden">
    <div class="modal-content">
        <form id="user-form" autocomplete="off">
            <div class="modal-header">
                <h3 id="modal-title" class="modal-title">Create New User</h3>
                <?= icon_button('close-outline', ['attributes' => ['class' => 'modal-close']]) ?>
            </div>
            <div class="modal-body">
                <div id="modal-errors"
                    class="hidden mb-4 p-3 bg-destructive/10 text-destructive border border-destructive/20 rounded-md text-sm">
                </div>
                <input type="hidden" id="user-id" name="id">

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <?= form_input('name', ['label' => 'Full Name', 'required' => true, 'attributes' => ['id' => 'user-name']]) ?>
                    <?= form_input('email', ['label' => 'Email Address', 'type' => 'email', 'required' => true, 'attributes' => ['id' => 'user-email']]) ?>
                </div>

                <?= form_input('password', ['label' => 'Password', 'type' => 'password', 'help_text' => 'Leave blank to keep current password.', 'attributes' => ['id' => 'user-password', 'autocomplete' => 'new-password']]) ?>

                <?php
                // Fetch tenants to populate the dropdown. This is done server-side for the initial render.
                $tenants = table('tenants')->orderBy('name')->get();
                $tenant_options = array_column($tenants, 'name', 'id');
                echo form_select('tenant_id', [
                    'label' => 'Tenant',
                    'required' => true,
                    'options' => $tenant_options,
                    'placeholder' => 'Select a Tenant',
                    'attributes' => ['id' => 'user-tenant']
                ]);
                ?>

                <div class="mt-4">
                    <?= form_checkbox('is_tenant_admin', ['label' => 'Is Tenant Administrator?', 'attributes' => ['id' => 'user-is-admin']]) ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                <?= button('Save User', ['type' => 'submit', 'variant' => 'primary', 'attributes' => ['id' => 'save-user-btn']]); ?>
            </div>
        </form>
    </div>
</div>

<!-- =================================================================
     Page-Specific JavaScript
     ================================================================= -->
<script>
    document.addEventListener('DOMContentLoaded', () => {
        // --- Custom Table Cell Renderers ---
        DynamicTable.addRenderer('userName', (value, row) => {
            const name = App.escapeHTML(row.name);
            const email = App.escapeHTML(row.email);
            return `<div class="font-medium text-fg">${name}</div><div class="text-xs text-fg-muted">${email}</div>`;
        });

        DynamicTable.addRenderer('actions', (id) => {
            return `
        <div class="table-actions justify-end">
            <a href="/users/${id}" class="btn btn-ghost btn-sm btn-icon" title="View User"><ion-icon name="eye-outline"></ion-icon></a>
            <button class="btn btn-ghost btn-sm btn-icon edit-btn" data-id="${id}" title="Edit User"><ion-icon name="pencil-outline"></ion-icon></button>
            <button class="btn btn-ghost btn-sm btn-icon text-destructive delete-btn" data-id="${id}" title="Delete User"><ion-icon name="trash-outline"></ion-icon></button>
        </div>`;
        });

        // --- Initialize the table ---
        DynamicTable.initAll();
        const usersTable = document.getElementById('users-table')?.dynamicTableInstance;
        if (!usersTable) return;

        // --- Element Selectors & Modal Logic ---
        const get = (id) => document.getElementById(id);
        const modal = get('user-modal');
        const form = get('user-form');
        const saveBtn = get('save-user-btn');
        const errorContainer = get('modal-errors');
        const passwordInput = get('user-password');
        const passwordLabel = passwordInput.closest('.form-group').querySelector('label');
        let activeModalCloser = null;

        const openModal = (mode = 'create', data = null) => {
            form.reset();
            get('user-id').value = '';
            errorContainer.classList.add('hidden');
            get('modal-title').textContent = mode === 'edit' ? 'Edit User' : 'Create New User';

            // Password is required only on create
            passwordInput.required = (mode === 'create');
            passwordLabel.classList.toggle('form-label-required', mode === 'create');

            if (mode === 'edit' && data) {
                get('user-id').value = data.id;
                get('user-name').value = data.name;
                get('user-email').value = data.email;
                get('user-tenant').value = data.tenant_id;
                get('user-is-admin').checked = !!data.is_tenant_admin; // Ensure boolean
            } else {
                get('user-is-admin').checked = false;
            }

            modal.classList.remove('hidden');
            setTimeout(() => modal.classList.add('visible'), 10);
            const handleEsc = (e) => { if (e.key === 'Escape') closeModal(); };
            document.addEventListener('keydown', handleEsc);
            activeModalCloser = () => document.removeEventListener('keydown', handleEsc);
        };

        const closeModal = () => {
            modal.classList.remove('visible');
            setTimeout(() => modal.classList.add('hidden'), 200);
            if (activeModalCloser) activeModalCloser();
        };

        const displayFormErrors = (errors) => {
            errorContainer.innerHTML = `<ul>${Object.values(errors).map(e => `<li>${App.escapeHTML(e)}</li>`).join('')}</ul>`;
            errorContainer.classList.remove('hidden');
        };

        // --- Event Listeners ---
        get('create-user-btn').addEventListener('click', () => openModal('create'));
        modal.querySelectorAll('.modal-close').forEach(el => el.addEventListener('click', closeModal));

        usersTable.element.addEventListener('click', async (e) => {
            const editBtn = e.target.closest('.edit-btn');
            if (editBtn) {
                try {
                    const result = await App.api(`users/${editBtn.dataset.id}`);
                    openModal('edit', result.data);
                } catch (error) {
                    App.notify.error(error.message || 'Failed to fetch user data.');
                }
            }

            const deleteBtn = e.target.closest('.delete-btn');
            if (deleteBtn) {
                try {
                    await App.confirm({
                        title: 'Delete User?',
                        message: 'Are you sure you want to delete this user? This action cannot be undone.',
                        confirmVariant: 'destructive'
                    });
                    const result = await App.api(`users/${deleteBtn.dataset.id}/delete`, { method: 'POST' });
                    App.notify.success(result.message);
                    usersTable.refresh();
                } catch (error) {
                    if (error && error.message) App.notify.error(error.message);
                    // If user cancels, the catch block is triggered without a message.
                }
            }
        });

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            saveBtn.classList.add('btn-loading');
            saveBtn.disabled = true;

            const id = get('user-id').value;
            const endpoint = id ? `users/${id}` : 'users';
            const formData = new FormData(form);

            // For updates, if the password is blank, remove it from the form data
            // so the backend doesn't try to update it to an empty string.
            if (id && !formData.get('password')) {
                formData.delete('password');
            }

            try {
                const result = await App.api(endpoint, { method: 'POST', body: formData });
                App.notify.success(result.message);
                closeModal();
                usersTable.refresh();
            } catch (error) {
                if (error.status === 422 && error.response.errors) {
                    displayFormErrors(error.response.errors);
                } else {
                    App.notify.error(error.message || 'An unexpected error occurred.');
                }
            } finally {
                saveBtn.classList.remove('btn-loading');
                saveBtn.disabled = false;
            }
        });
    });
</script>