<?php /**
  * app/views/system/users/view.php
  * Displays a detailed profile for a single user.
  */
?>
<div id="user-profile-container">
    <!-- Loading placeholder -->
    <div id="loading-placeholder">
        <?= card([
            'body' => '<div class="flex items-center justify-center p-12"><ion-icon name="reload-outline" class="w-8 h-8 animate-spin text-accent"></ion-icon></div>'
        ]) ?>
    </div>

    <!-- User profile will be rendered here by JavaScript -->
    <div id="user-profile-content" class="hidden"></div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const userId = '<?= h($user_id ?? '') ?>';
        const container = document.getElementById('user-profile-content');
        const loader = document.getElementById('loading-placeholder');

        if (!userId) {
            loader.innerHTML = '<?= card(['body' => '<p class="text-destructive text-center p-8">User ID not provided.</p>']) ?>';
            return;
        }

        const renderProfile = (user) => {
            const adminBadges = [];
            if (user.is_app_admin) {
                adminBadges.push('<span class="badge badge-info">Super Admin</span>');
            }
            if (user.is_tenant_admin) {
                adminBadges.push('<span class="badge badge-success">Tenant Admin</span>');
            }

            const profileHeader = `
                <div class="flex flex-col md:flex-row items-start md:items-center gap-4">
                    <div class="avatar avatar-lg avatar-fallback rounded-full flex items-center justify-center text-2xl">
                        ${App.escapeHTML(user.name.charAt(0))}
                    </div>
                    <div class="flex-1">
                        <h1 class="text-2xl font-bold">${App.escapeHTML(user.name)}</h1>
                        <p class="text-fg-muted">${App.escapeHTML(user.email)}</p>
                        <div class="flex items-center gap-2 mt-2">
                            ${adminBadges.join('')}
                        </div>
                    </div>
                    <div class="flex items-center gap-2">
                        <button class="btn btn-secondary edit-btn" data-id="${user.id}"><ion-icon name="pencil-outline"></ion-icon><span>Edit User</span></button>
                    </div>
                </div>
            `;

            const detailsCard = `
                <div class="card">
                    <div class="card-header"><h3 class="card-title">User Details</h3></div>
                    <div class="card-body">
                        <dl class="stats-list">
                            <div class="stats-list-item"><dt>Tenant</dt><dd>${user.tenant_name ? App.escapeHTML(user.tenant_name) : '<span class="text-fg-muted">N/A</span>'}</dd></div>
                            <div class="stats-list-item"><dt>User ID</dt><dd><code>${user.id}</code></dd></div>
                            <div class="stats-list-item"><dt>Joined On</dt><dd>${new Date(user.created_at).toLocaleDateString()}</dd></div>
                        </dl>
                    </div>
                </div>
            `;

            const rolesCard = `
                <div class="card">
                    <div class="card-header"><h3 class="card-title">Assigned Roles</h3></div>
                    <div class="card-body">
                        ${user.roles && user.roles.length > 0 ?
                    `<div class="flex flex-wrap gap-2">${user.roles.map(role => `<span class="badge badge-secondary">${App.escapeHTML(role)}</span>`).join('')}</div>` :
                    '<p class="text-fg-muted">This user has no roles assigned.</p>'
                }
                    </div>
                </div>
            `;

            container.innerHTML = `
                <div class="flex flex-col gap-6">
                    ${profileHeader}
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        ${detailsCard}
                        ${rolesCard}
                    </div>
                </div>
            `;
        };

        const fetchUser = async () => {
            try {
                const result = await App.api(`users/${userId}`);
                renderProfile(result.data);
                loader.classList.add('hidden');
                container.classList.remove('hidden');
            } catch (error) {
                const errorCard = `<div class="card card-outline"><div class="card-body text-center p-8"><h3 class="font-semibold text-destructive">Could not load user</h3><p class="text-fg-muted mt-2">${error.message}</p></div></div>`;
                loader.innerHTML = errorCard;
            }
        };

        fetchUser();
    });
</script>

<style>
    .stats-list {
        display: flex;
        flex-direction: column;
        gap: var(--space-3);
    }

    .stats-list-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: var(--space-4);
        font-size: var(--font-size-sm);
        border-bottom: 1px solid rgb(var(--color-border-subtle));
        padding-bottom: var(--space-3);
    }

    .stats-list-item:last-child {
        border-bottom: none;
    }

    .stats-list-item dt {
        color: rgb(var(--color-fg-muted));
    }

    .stats-list-item dd {
        font-weight: var(--font-weight-medium);
        color: rgb(var(--color-fg));
        text-align: right;
    }
</style>