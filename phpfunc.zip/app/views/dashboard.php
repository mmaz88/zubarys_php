<?php
/**
 * app/views/dashboard.php
 * The main dashboard view, redesigned to be a welcoming and informative
 * introduction for developers using the framework.
 * Uses custom CSS classes and helper functions.
 */

// Greet the user by name, with a fallback if the session isn't set.
$user_name = h(session('user_name', 'Developer'));
?>

<!-- Main container with vertical gap -->
<div class="flex flex-col gap-6"> <!-- Assuming these flex/grid classes are part of your utility system or defined -->

    <!-- Welcome Header -->
    <div>
        <h1 class="page-title">Welcome, <?= $user_name ?>!</h1> <!-- Use page-title class -->
        <!-- Apply text color and margin using CSS variables -->
        <p style="color: rgb(var(--color-fg-muted)); margin-top: var(--space-2);">
            You've successfully logged into the PHP Functional Mini-Framework.
        </p>
    </div>

    <!-- About This Project Card -->
    <?php
    // Use the updated card helper
    echo card([
        'header' => [
            'title' => 'About This Framework',
            'subtitle' => 'A lightweight foundation for modern PHP applications.'
        ],
        'body' => '
            <p style="margin-bottom: var(--space-4);">This project is an exploration of building a modern, API-first web application using a <strong>functional programming paradigm</strong> in PHP. Instead of relying on heavy classes, complex inheritance, or a traditional MVC structure, the core is built with simple, reusable helper functions.</p>
            <p style="margin-bottom: 0;">The goal is to provide a lean, understandable, and multi-tenant capable foundation that is both easy to learn and powerful enough for real-world projects.</p>
        ',
        // Removed shadow class, rely on CSS or card default
        'attributes' => [] // Add other attributes if needed
    ]);
    ?>

    <!-- Key Features Section -->
    <div>
        <h2
            style="font-size: var(--font-size-xl); font-weight: var(--font-weight-semibold); margin-bottom: var(--space-4);">
            Key Features</h2>
        <!-- Use card_grid helper for consistent spacing -->
        <?php
        $features = [
            [
                'icon' => 'flash-outline',
                'title' => 'Functional Core',
                'description' => 'A lean codebase built with simple, reusable helper functions for clarity and performance.'
            ],
            [
                'icon' => 'code-working-outline',
                'title' => 'API-First Design',
                'description' => 'Clean separation between the backend logic and the frontend, perfect for modern web apps.'
            ],
            [
                'icon' => 'layers-outline',
                'title' => 'Component-Based UI',
                'description' => 'Quickly build consistent interfaces with a library of view helpers for cards, forms, and buttons.'
            ],
            [
                'icon' => 'server-outline',
                'title' => 'Database Agnostic',
                'description' => 'Powered by PDO with a simple query builder and Phinx for version-controlled migrations.'
            ],
            [
                'icon' => 'business-outline',
                'title' => 'Multi-Tenant Ready',
                'description' => 'Designed with a shared database tenancy model for scalable, isolated client environments.'
            ],
            [
                'icon' => 'shield-checkmark-outline',
                'title' => 'Security Focused',
                'description' => 'Includes built-in CSRF protection, password hashing, and a flexible middleware pipeline.'
            ]
        ];

        // Prepare card HTML strings for the grid
        $feature_cards = [];
        foreach ($features as $feature) {
            $card_html = card([
                'body' => '
                    <div style="display: flex; align-items: flex-start; gap: var(--space-4);">
                        <ion-icon name="' . h($feature['icon']) . '" style="color: rgb(var(--color-accent)); font-size: var(--font-size-2xl); margin-top: var(--space-1);"></ion-icon>
                        <div>
                            <h3 style="font-weight: var(--font-weight-medium); color: rgb(var(--color-fg));">' . h($feature['title']) . '</h3>
                            <p style="color: rgb(var(--color-fg-muted)); font-size: var(--font-size-sm); margin-top: var(--space-1); margin-bottom: 0;">' . h($feature['description']) . '</p>
                        </div>
                    </div>
                ',
                'variant' => 'outline',
                'interactive' => true,
                'attributes' => ['style' => 'height: 100%;'] // Ensure cards take height if needed
            ]);
            $feature_cards[] = $card_html;
        }

        // Render the grid of feature cards
        echo card_grid($feature_cards, ['columns' => '1 md:2 lg:3', 'gap' => '6']); // Adjust columns/gap as needed, matching utility classes or CSS
        ?>
    </div>

    <!-- Next Steps & System Info Section -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6"> <!-- Use grid and gap -->

        <?php
        // Card for "Next Steps"
        echo card([
            'header' => ['title' => 'Explore the UI Components'],
            'body' => '<p style="margin-bottom: 0;">The best way to get started is by exploring the component library. See how the view helpers work and test them in a live environment.</p>',
            'footer' => button('Go to Component Library', [
                'href' => '/components',
                'variant' => 'primary',
                'icon' => 'arrow-forward-outline',
                'icon_position' => 'after',
                'attributes' => ['style' => 'width: 100%;'] // Responsive button - adjust via CSS media queries if needed
            ])
        ]);

        // Card for "System Info"
        echo card([
            'header' => ['title' => 'System Information'],
            'body' => '
                <ul style="display: flex; flex-direction: column; gap: var(--space-3);"> <!-- Use gap for list item spacing -->
                    <li style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="color: rgb(var(--color-fg-muted));">PHP Version:</span>
                        <strong style="color: rgb(var(--color-fg));">' . phpversion() . '</strong>
                    </li>
                    <li style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="color: rgb(var(--color-fg-muted));">App Environment:</span>
                        <span style="font-weight: var(--font-weight-medium); padding: var(--space-1) var(--space-2); font-size: var(--font-size-xs); border-radius: var(--radius-full); background-color: rgb(var(--color-bg-muted)); color: rgb(var(--color-fg));">
                            ' . h(env('APP_ENV', 'production')) . '
                        </span>
                    </li>
                     <li style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="color: rgb(var(--color-fg-muted));">Debug Mode:</span>
                        <strong>' .
                (is_debug() ?
                    '<span style="color: rgb(var(--color-success));">Enabled</span>' : // Use success color
                    '<span style="color: rgb(var(--color-destructive));">Disabled</span>' // Use destructive color
                ) .
                '</strong>
                    </li>
                </ul>
            '
        ]);
        ?>
    </div>

</div>