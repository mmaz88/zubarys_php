<?php
/**
 * app/views/home.php
 * The main landing page for the framework, built with Bootstrap 5.
 */
?>

<div class="container">
    <!-- Header -->
    <header class="text-center py-5 mb-4 border-bottom">
        <div class="text-primary mb-3">
            <ion-icon name="cube-outline" style="font-size: 4rem;"></ion-icon>
        </div>
        <h1 class="display-5 fw-bold text-body-emphasis">Welcome to the PHP Functional Framework</h1>
        <div class="col-lg-6 mx-auto">
            <p class="lead mb-4">
                A lightweight, multi-tenant capable foundation for building modern web applications with an API-first approach, now styled with Bootstrap 5.
            </p>
        </div>
    </header>

    <main>
        <!-- Core Features Grid -->
        <h2 class="text-center mb-4">Core Features</h2>
        <div class="row g-4 mb-5">
            <?php
            $features = [
                ['icon' => 'layers-outline', 'title' => 'Functional Core', 'description' => 'Built with simple, reusable helper functions instead of complex classes for a lean and understandable codebase.', 'color' => 'primary'],
                ['icon' => 'business-outline', 'title' => 'Multi-Tenant Ready', 'description' => 'Designed with a shared database tenancy model, allowing for scalable, isolated client environments.', 'color' => 'success'],
                ['icon' => 'flash-outline', 'title' => 'API-First Design', 'description' => 'A clear separation between the frontend and backend with well-defined API routes, perfect for modern applications.', 'color' => 'purple'],
                ['icon' => 'server-outline', 'title' => 'Database Migrations', 'description' => 'Powered by Phinx for robust, version-controlled schema management, ensuring database consistency.', 'color' => 'info'],
                ['icon' => 'shield-checkmark-outline', 'title' => 'Security Focused', 'description' => 'Includes built-in CSRF protection, password hashing, and a middleware pipeline for authentication.', 'color' => 'danger'],
                ['icon' => 'grid-outline', 'title' => 'Component-Based UI', 'description' => 'Reusable UI components built with Bootstrap 5 and Vanilla JS for a consistent and modern user interface.', 'color' => 'warning']
            ];

            foreach ($features as $feature) {
                echo '
                <div class="col-md-6 col-lg-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body d-flex align-items-start">
                            <div class="flex-shrink-0 me-3">
                                <ion-icon name="' . $feature['icon'] . '" class="fs-2 text-' . $feature['color'] . '"></ion-icon>
                            </div>
                            <div>
                                <h5 class="card-title">' . $feature['title'] . '</h5>
                                <p class="card-text text-muted">' . $feature['description'] . '</p>
                            </div>
                        </div>
                    </div>
                </div>';
            }
            ?>
        </div>

        <!-- System Health and Architecture Section -->
        <div class="row g-4">
            <!-- System Health Card -->
            <div class="col-lg-5">
                <div class="card shadow-sm">
                    <div class="card-header d-flex align-items-center">
                        <ion-icon name="pulse-outline" class="me-2 text-success"></ion-icon>
                        <span class="fw-bold">Live System Health</span>
                    </div>
                    <div class="card-body">
                        <p class="card-text text-muted small">
                            This is a live check of the core services via API calls to <code>/api/system/*</code>.
                        </p>
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                API Status
                                <span class="d-flex align-items-center">
                                    <span class="spinner-grow spinner-grow-sm me-2" role="status" id="api-status-indicator"></span>
                                    <span class="fw-medium" id="api-status-text">Checking...</span>
                                </span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Database Connection
                                <span class="d-flex align-items-center">
                                    <span class="spinner-grow spinner-grow-sm me-2" role="status" id="db-status-indicator"></span>
                                    <span class="fw-medium" id="db-status-text">Checking...</span>
                                </span>
                            </li>
                        </ul>
                        <div id="db-status-message" class="form-text mt-2" style="min-height: 1.25rem;"></div>
                    </div>
                </div>
            </div>

            <!-- Technology Stack Card -->
            <div class="col-lg-7">
                <div class="card shadow-sm">
                     <div class="card-header d-flex align-items-center">
                        <ion-icon name="code-slash-outline" class="me-2 text-primary"></ion-icon>
                        <span class="fw-bold">Technology Stack</span>
                    </div>
                    <div class="card-body">
                         <div class="row row-cols-2 row-cols-sm-4 g-3 text-center">
                             <div class="col">
                                 <div class="p-3 bg-body-tertiary rounded">
                                     <ion-icon name="logo-javascript" class="text-warning" style="font-size: 2.5rem;"></ion-icon>
                                     <p class="mb-0 mt-2 small">Bootstrap 5 & JS</p>
                                 </div>
                             </div>
                              <div class="col">
                                 <div class="p-3 bg-body-tertiary rounded">
                                     <i class="bi bi-filetype-php" style="font-size: 2.5rem; color: #7A86B8;"></i>
                                     <p class="mb-0 mt-2 small">Core PHP 8+</p>
                                 </div>
                             </div>
                              <div class="col">
                                 <div class="p-3 bg-body-tertiary rounded">
                                     <ion-icon name="git-branch-outline" class="text-info" style="font-size: 2.5rem;"></ion-icon>
                                     <p class="mb-0 mt-2 small">FastRoute</p>
                                 </div>
                             </div>
                              <div class="col">
                                 <div class="p-3 bg-body-tertiary rounded">
                                     <ion-icon name="server-outline" class="text-success" style="font-size: 2.5rem;"></ion-icon>
                                     <p class="mb-0 mt-2 small">PDO + Phinx</p>
                                 </div>
                             </div>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="text-center py-4 mt-5">
        <p class="text-muted">PHP v<?= phpversion() ?> | Built for Scale</p>
    </footer>
</div>

<script>
(function checkSystemStatus() {
    const apiStatusIndicator = document.getElementById('api-status-indicator');
    const apiStatusText = document.getElementById('api-status-text');
    const dbStatusIndicator = document.getElementById('db-status-indicator');
    const dbStatusText = document.getElementById('db-status-text');
    const dbStatusMessage = document.getElementById('db-status-message');

    if (!apiStatusIndicator || !dbStatusIndicator) return;

    const updateStatusUI = (indicator, textEl, status, onlineText, errorText) => {
        indicator.classList.remove('spinner-grow');
        indicator.className = 'd-inline-block rounded-circle me-2';
        indicator.style.width = '10px';
        indicator.style.height = '10px';
        
        if (status === 'ok') {
            indicator.classList.add('bg-success');
            textEl.textContent = onlineText;
            textEl.className = 'text-success fw-medium';
        } else {
            indicator.classList.add('bg-danger');
            textEl.textContent = errorText;
            textEl.className = 'text-danger fw-medium';
        }
    };

    // 1. Check API status
    fetch('/api/system/health')
        .then(response => response.ok ? response.json() : Promise.reject(response))
        .then(data => updateStatusUI(apiStatusIndicator, apiStatusText, data.data.status, 'Online', 'Error'))
        .catch(() => updateStatusUI(apiStatusIndicator, apiStatusText, 'error', 'Online', 'Error'));

    // 2. Check DB status
    fetch('/api/system/db')
        .then(response => response.json())
        .then(data => {
            updateStatusUI(dbStatusIndicator, dbStatusText, data.success ? 'ok' : 'error', 'Connected', 'Error');
            dbStatusMessage.textContent = data.message || '';
        })
        .catch(() => {
            updateStatusUI(dbStatusIndicator, dbStatusText, 'error', 'Connected', 'Error');
            dbStatusMessage.textContent = 'Could not reach DB health endpoint.';
        });
})();
</script>