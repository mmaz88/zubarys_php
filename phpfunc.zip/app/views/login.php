<?php /** * app/views/login.php * No changes needed here now that the helper is fixed, but showing for completeness. */ ?>

<div class="card shadow-lg">
    <div class="card-body p-8">
        <form id="login-form" class="form">
            <?= csrf_field() ?>

            <div class="text-center mb-6">
                <ion-icon name="cube-outline" class="text-accent" style="font-size: 3rem;"></ion-icon>
                <h1 class="text-2xl font-bold mt-2">Please sign in</h1>
            </div>

            <div id="error-message-container"></div>

            <?= form_input('email', [
                'label' => 'Email address',
                'required' => true,
                'size' => 'lg',
                'attributes' => ['placeholder' => 'admin@acme.com', 'value' => 'admin@acme.com']
            ]) ?>
            <?= form_input('password', [
                'type' => 'password',
                'label' => 'Password',
                'required' => true,
                'size' => 'lg',
                'attributes' => ['placeholder' => '••••••••', 'value' => '123456789']
            ]) ?>

            <div class="flex items-center justify-between mt-2 mb-4">
                <?= form_checkbox('remember_me', [
                    'label' => 'Remember me',
                    'id' => 'rememberMe'
                ]) ?>
                <a href="#" class="text-sm font-medium text-accent hover:underline">Forgot password?</a>
            </div>

            <?= button('Sign in', [
                'variant' => 'primary',
                'type' => 'submit', // This will now correctly generate type="submit"
                'attributes' => ['class' => 'w-full btn-lg']
            ]) ?>

            <p class="text-center text-sm text-muted mt-4">
                Or <a href="/register" class="font-medium text-accent hover:underline">create a new account</a>
            </p>
        </form>
    </div>
</div>