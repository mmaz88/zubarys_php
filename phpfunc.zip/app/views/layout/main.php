<?php // app/views/layout/main.php

// --- MENU STRUCTURE ---
$menu = [
    [
        'text' => 'Main Navigation',
        'is_heading' => true,
        'children' => [
            ['text' => 'Dashboard', 'slug' => 'dashboard', 'icon' => 'grid-outline'],
        ]
    ],
    [
        'text' => 'Core Systems',
        'is_heading' => true,
        'children' => [
            ['text' => 'Tenants', 'slug' => 'tenants', 'icon' => 'business-outline'],
            ['text' => 'Users', 'slug' => 'users', 'icon' => 'people-outline'],
            ['text' => 'Roles & Permissions', 'slug' => 'roles', 'icon' => 'shield-checkmark-outline'],
        ]
    ],
];

$brand_config = ['name' => 'PHP Func', 'icon' => 'cube-outline', 'url' => '/dashboard'];

$user_data = [
    'name' => session('user_name', 'Acme Admin'),
    'email' => session('user_email', 'admin@acme.com'),
    'avatar' => 'https://i.pravatar.cc/150?u=admin'
];



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($title ?? 'PHP Func') ?> | PHP Func</title>
    <!-- Google Fonts (Inter) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- CRITICAL: PRE-RENDER SCRIPTS FOR STATE RESTORATION
    These scripts run before the page is rendered to prevent flicker.
    They read localStorage and apply classes to the root <html> element. -->
    <script>
        (function () {
            try {
                // Apply theme immediately to prevent flash
                const savedTheme = localStorage.getItem('theme');
                let theme;
                if (savedTheme) {
                    theme = savedTheme;
                } else {
                    theme = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
                }
                document.documentElement.setAttribute('data-theme', theme);

                // Apply sidebar state immediately
                if (localStorage.getItem('sidebarCollapsed') === 'true') {
                    document.documentElement.classList.add('sidebar-collapsed');
                }
            } catch (e) {
                // Fallback to light theme if localStorage fails
                document.documentElement.setAttribute('data-theme', 'light');
                console.error('Could not access localStorage for theme/sidebar state.', e);
            }
        })();
    </script>
    <!-- END: PRE-RENDER SCRIPTS -->

    <!-- Design System CSS -->
    <?= css('main.css') ?>

    <!-- Ionicons -->
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</head>

<body>
    <!-- App Layout Container -->
    <div class="app-layout">
        <!-- Sidebar -->
        <?= render_app_sidebar($menu, false, $brand_config) ?>

        <!-- Main Content Area Wrapper -->
        <div class="main-content">
            <!-- Topbar/Header -->
            <?= render_app_header($page_title ?? 'Page', $user_data, $breadcrumbs ?? []) ?>

            <!-- The actual content area inside the wrapper, with padding -->
            <main class="content-area">
                <?= $content ?? '' ?>
            </main>
        </div>
    </div>


    <!-- =================================================================
    Reusable Confirmation Modal
    ================================================================= -->
    <div id="confirmation-modal" class="modal-overlay hidden">
        <div class="modal-content modal-sm">
            <div class="modal-header">
                <h3 id="confirmation-modal-title" class="modal-title">Confirm Action</h3>
            </div>
            <div class="modal-body">
                <p id="confirmation-modal-message">Are you sure you want to proceed with this action?</p>
            </div>
            <div class="modal-footer">
                <button type="button" id="confirmation-modal-cancel" class="btn btn-secondary">Cancel</button>
                <button type="button" id="confirmation-modal-confirm" class="btn btn-destructive">Confirm</button>
            </div>
        </div>
    </div>

    <?= js('alert.js') ?>
    <?= js('app.js') ?>
    <?= js('table.js') ?>

    <script>
        window.AppConfig = {
            baseUrl: "<?= h(get_base_url()) ?>",
            apiUrl: "<?= h(get_base_url() . '/api') ?>"
        };
    </script>

    <script>
        document.addEventListener("DOMContentLoaded", () => {
            // --- Theme Manager (Updated) ---
            const themeManager = {
                init() {
                    // Theme is already applied by pre-render script
                    // Just set up event listeners and icon updates
                    this.updateThemeIcons();
                    document.querySelectorAll("[data-theme-toggle]").forEach(btn => {
                        btn.addEventListener("click", () => this.toggleTheme());
                    });
                    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
                        if (localStorage.getItem('theme') === null) {
                            this.updateTheme(e.matches ? 'dark' : 'light');
                        }
                    });
                },
                getCurrentTheme() {
                    return document.documentElement.getAttribute('data-theme');
                },
                toggleTheme() {
                    const currentTheme = this.getCurrentTheme();
                    const newTheme = currentTheme === "light" ? "dark" : "light";
                    localStorage.setItem("theme", newTheme);
                    this.updateTheme(newTheme);
                },
                updateTheme(theme) {
                    document.documentElement.setAttribute('data-theme', theme);
                    this.updateThemeIcons();
                },
                updateThemeIcons() {
                    const currentTheme = this.getCurrentTheme();
                    const sunIcons = document.querySelectorAll("[data-sun-icon]");
                    const moonIcons = document.querySelectorAll("[data-moon-icon]");

                    sunIcons.forEach(i => {
                        if (currentTheme === "light") {
                            i.classList.add("hidden");
                        } else {
                            i.classList.remove("hidden");
                        }
                    });

                    moonIcons.forEach(i => {
                        if (currentTheme === "dark") {
                            i.classList.add("hidden");
                        } else {
                            i.classList.remove("hidden");
                        }
                    });
                }


            };

            // --- Sidebar Manager (Updated) ---
            const sidebarManager = {
                init() {
                    this.htmlEl = document.documentElement;
                    this.sidebar = document.getElementById('main-sidebar');
                    this.toggleButton = document.getElementById('sidebar-toggle');
                    this.mobileToggle = document.getElementById('mobile-sidebar-toggle');

                    // Sidebar state is already applied by pre-render script
                    // Just update CSS variable and tooltip
                    this.updateCSSVariable();
                    this.updateToggleTooltip();

                    if (this.toggleButton) {
                        this.toggleButton.addEventListener("click", () => this.toggle());
                    }

                    if (this.mobileToggle) {
                        this.mobileToggle.addEventListener("click", () => this.toggleMobile());
                    }
                },
                toggle() {
                    const isCollapsed = this.htmlEl.classList.toggle("sidebar-collapsed");
                    localStorage.setItem("sidebarCollapsed", isCollapsed ? "true" : "false");
                    this.updateCSSVariable();
                    this.updateToggleTooltip();
                },
                updateCSSVariable() {
                    const isCollapsed = this.htmlEl.classList.contains('sidebar-collapsed');
                    const sidebarWidth = isCollapsed ? 'var(--sidebar-width-collapsed)' : 'var(--sidebar-width-expanded)';
                    document.documentElement.style.setProperty('--sidebar-current-width', sidebarWidth);
                },
                updateToggleTooltip() {
                    if (this.toggleButton) {
                        const isCollapsed = this.htmlEl.classList.contains('sidebar-collapsed');
                        const tooltipText = isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar';
                        this.toggleButton.setAttribute('data-tooltip', tooltipText);
                    }
                },
                toggleMobile() {
                    this.sidebar.classList.toggle('open');
                }
            };

            // Initialize managers
            themeManager.init();
            sidebarManager.init();

            // Make sidebarManager globally available for mobile toggle if needed
            window.sidebarManager = sidebarManager;
        });
    </script>

</body>

</html>