<?php /** * app/views/layout/public.php * CORRECTED: Adds the dedicated login.js script. */ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($title ?? 'PHP Framework') ?></title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Design System CSS -->
    <?= css('main.css') ?>
    <!-- Ionicons -->
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</head>

<body class="flex items-center justify-center min-h-screen bg-subtle p-4">
    <main class="w-full max-w-md">
        <?= $content ?? '' ?>
    </main>

    <!-- Alert System (for login feedback, etc.) -->
    <?= js('alert.js') ?>
    <!-- Login page specific script -->
    <?= js('auth/login.js') ?>

    <script>
        // Basic theme handler for public pages
        document.addEventListener("DOMContentLoaded", () => {
            const theme = localStorage.getItem("theme") || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
            document.documentElement.dataset.theme = theme;
        });
    </script>
</body>

</html>