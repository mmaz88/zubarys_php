<?php
// app/helpers/vw_card_helpers.php
declare(strict_types=1);

if (!function_exists('card')) {
    /**
     * Renders a card component.
     *
     * @param array<string, mixed> $options Configuration options:
     *   - 'header' (array|null): Header configuration.
     *     - 'title' (string): Card title.
     *     - 'subtitle' (string): Card subtitle.
     *     - 'actions' (string): HTML for header actions (e.g., buttons).
     *   - 'media' (string): HTML for media content (e.g., <img>).
     *   - 'body' (string): The main content of the card.
     *   - 'footer' (array|null): Footer configuration.
     *     - 'content' (string): Footer content.
     *     - 'actions' (string): HTML for footer actions.
     *   - 'variant' (string|null): Card variant ('outline', 'ghost'). Default null.
     *   - 'interactive' (bool): Whether the card is interactive (adds 'card-interactive'). Default false.
     *   - 'compact' (bool): Whether to use compact padding (adds 'card-compact'). Default false.
     *   - 'attributes' (array): Additional HTML attributes for the card container. Default [].
     * @return string The rendered HTML for the card.
     */
    function card(array $options = []): string
    {
        // Extract options with defaults
        $header = $options['header'] ?? null;
        $media = $options['media'] ?? null;
        $body = $options['body'] ?? '';
        $footer = $options['footer'] ?? null;
        $variant = $options['variant'] ?? null;
        $interactive = $options['interactive'] ?? false;
        $compact = $options['compact'] ?? false;
        $attributes = $options['attributes'] ?? [];

        // --- Class Name Generation ---
        $classes = ['card'];
        if ($variant) {
            $classes[] = 'card-' . $variant;
        }
        if ($interactive) {
            $classes[] = 'card-interactive';
        }
        if ($compact) {
            $classes[] = 'card-compact'; // Apply compact class if needed
        }
        if (!empty($attributes['class'])) {
            $classes[] = $attributes['class'];
        }
        $attributes['class'] = implode(' ', array_unique(array_filter($classes)));

        // --- Start Building HTML ---
        $html = '<div ' . build_attributes($attributes) . '>';

        // --- Header ---
        if ($header) {
            $html .= '<div class="card-header">';
            // Title and Subtitle
            if (!empty($header['title']) || !empty($header['subtitle'])) {
                $html .= '<div class="card-header-main">'; // Optional wrapper for title/subtitle
                if (!empty($header['title'])) {
                    // Use h3 as per CSS examples
                    $html .= '<h3 class="card-title">' . h($header['title']) . '</h3>';
                }
                if (!empty($header['subtitle'])) {
                    // Use p as per CSS examples
                    $html .= '<p class="card-subtitle">' . h($header['subtitle']) . '</p>';
                }
                $html .= '</div>';
            }
            // Actions (e.g., buttons/icons)
            if (!empty($header['actions'])) {
                $html .= '<div class="card-actions">' . $header['actions'] . '</div>';
            }
            $html .= '</div>';
        }

        // --- Media ---
        if ($media) {
            $html .= '<div class="card-media">' . $media . '</div>';
        }

        // --- Body ---
        if ($body) {
            $html .= '<div class="card-body">';
            $html .= $body;
            $html .= '</div>';
        }

        // --- Footer ---
        if ($footer) {
            $footerClasses = ['card-footer'];
            if ($compact && !empty($footer['content']) && empty($footer['actions'])) {
                // Apply compact class only if it's a simple content footer in compact mode
                // Adjust logic as needed based on your CSS
                // $footerClasses[] = 'card-footer-compact';
            }
            $footerAttrString = build_attributes(['class' => implode(' ', $footerClasses)]);

            $html .= '<div ' . $footerAttrString . '>';
            if (!empty($footer['content'])) {
                $html .= '<div class="card-footer-content">' . $footer['content'] . '</div>';
            }
            if (!empty($footer['actions'])) {
                $html .= '<div class="card-footer-actions">' . $footer['actions'] . '</div>';
            }
            $html .= '</div>';
        }

        $html .= '</div>'; // Close the card div

        return $html;
    }
}

if (!function_exists('card_grid')) {
    /**
     * Renders a grid of cards using utility classes.
     *
     * @param array $cards An array of HTML strings representing individual cards.
     * @param array $options Configuration options:
     *   - 'columns' (string|int): Number of columns (e.g., 1, 2, 3, 'auto'). Default 3.
     *   - 'gap' (string): Gap size (e.g., '2', '4', '6'). Default '4'.
     *   - 'attributes' (array): Additional attributes for the grid container. Default [].
     * @return string The rendered HTML for the card grid.
     */
    function card_grid(array $cards, array $options = []): string
    {
        if (empty($cards)) {
            return '';
        }

        $columns = $options['columns'] ?? 3;
        $gap = $options['gap'] ?? 4;
        $attributes = $options['attributes'] ?? [];

        // --- Class Name Generation ---
        $classes = ['card-grid'];
        // Handle responsive columns if needed, e.g., 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
        // For simplicity, assuming direct class application
        if (is_numeric($columns)) {
            $classes[] = "grid-cols-{$columns}";
        } else {
            // Handle 'auto' or responsive classes passed as string
            $classes[] = "grid-cols-{$columns}";
        }
        $classes[] = "gap-{$gap}";

        if (!empty($attributes['class'])) {
            $classes[] = $attributes['class'];
        }
        $attributes['class'] = implode(' ', array_unique(array_filter($classes)));

        return "<div " . build_attributes($attributes) . ">" . implode('', $cards) . '</div>';
    }
}