<?php
// app/helpers/navigation_helper.php
declare(strict_types=1);

// ===============================================
// Navigation Components
// ===============================================

if (!function_exists('navbar')) {
    /**
     * Renders a navigation bar using custom CSS classes.
     * @param array<string, mixed> $options Configuration options:
     *   - 'brand' (string|null): Brand name or logo HTML
     *   - 'brand_url' (string): URL for brand link
     *   - 'items' (array): Navigation items
     *   - 'actions' (string|null): Right-side action buttons HTML
     *   - 'fixed' (bool): Whether navbar is fixed to top
     *   - 'transparent' (bool): Whether navbar has transparent background
     * @return string The rendered HTML for the navbar.
     */
    function navbar(array $options = []): string
    {
        $brand = $options['brand'] ?? null;
        $brandUrl = $options['brand_url'] ?? '/';
        $items = $options['items'] ?? [];
        $actions = $options['actions'] ?? null;
        $fixed = $options['fixed'] ?? false;
        $transparent = $options['transparent'] ?? false;

        $baseClasses = 'topbar';
        if ($fixed) {
            $baseClasses .= ' sticky top-0'; // Use sticky if fixed is intended to be relative to viewport top
        }
        // Note: Transparency handled via CSS variables or specific classes if needed

        $html = '<nav class="' . $baseClasses . '" role="navigation" aria-label="Main navigation">';
        // Consider if a container div is needed based on your layout CSS
        // $html .= '<div class="topbar-content">'; // If your layout requires this wrapper

        // Left side - Brand and main navigation
        $html .= '<div class="topbar-left">';

        // Brand
        if ($brand) {
            $html .= '<div class="flex items-center gap-3">'; // Use flex utilities if not covered by topbar-left
            $html .= '<a href="' . h($brandUrl) . '" class="text-lg font-semibold text-fg">'; // Use text-fg for color
            $html .= $brand;
            $html .= '</a>';
            $html .= '</div>';
        }

        // Main navigation
        if (!empty($items)) {
            $html .= '<nav class="nav nav-horizontal" aria-label="Primary">'; // Use nav component classes
            foreach ($items as $item) {
                $url = $item['url'] ?? '#';
                $text = $item['text'] ?? '';
                $active = $item['active'] ?? false;
                $icon = $item['icon'] ?? null;

                $linkClasses = 'nav-item';
                if ($active) {
                    $linkClasses .= ' active';
                }

                $html .= '<a href="' . h($url) . '" class="' . $linkClasses . '">'; // nav-item provides padding, etc.
                if ($icon) {
                    // Assuming .icon class exists or use inline styles for size
                    $html .= '<i data-lucide="' . $icon . '" class="icon"></i>';
                }
                $html .= h($text);
                $html .= '</a>';
            }
            $html .= '</nav>';
        }

        $html .= '</div>'; // .topbar-left

        // Right side - Actions
        if ($actions) {
            $html .= '<div class="topbar-right">';
            $html .= '<div class="topbar-actions">'; // Group actions
            $html .= $actions;
            $html .= '</div>';
            $html .= '</div>';
        }

        // $html .= '</div>'; // Close container div if used
        $html .= '</nav>';

        return $html;
    }
}

if (!function_exists('breadcrumb')) {
    /**
     * Renders a breadcrumb navigation using custom CSS classes.
     * @param array<array<string, string>> $items Breadcrumb items with 'text' and 'url' keys.
     * @param array<string, mixed> $options Configuration options.
     * @return string The rendered HTML for the breadcrumb.
     */
    function breadcrumb(array $items, array $options = []): string
    {
        if (empty($items)) {
            return '';
        }

        $separator = $options['separator'] ?? 'chevron-right';

        $html = '<nav class="breadcrumb" aria-label="Breadcrumb">';
        $html .= '<ol class="flex items-center gap-2">'; // Use flex/gap for layout

        foreach ($items as $index => $item) {
            $isLast = $index === count($items) - 1;
            $text = $item['text'] ?? '';
            $url = $item['url'] ?? null;

            $html .= '<li class="breadcrumb-item">'; // Use breadcrumb-item class

            if (!$isLast && $url) {
                $html .= '<a href="' . h($url) . '" class="text-fg-subtle hover:text-fg transition-colors">'; // Style links
                $html .= h($text);
                $html .= '</a>';
            } else {
                // Last item or item without URL is current/label
                $html .= '<span class="text-fg font-medium">' . h($text) . '</span>'; // Style current item
            }

            // Separator (except for last item)
            if (!$isLast) {
                // Separator added via CSS pseudo-element or explicitly
                // Using explicit icon for clarity, styled via CSS

            }

            $html .= '</li>';
        }

        $html .= '</ol>';
        $html .= '</nav>';

        return $html;
    }
}

if (!function_exists('sidebar')) {
    /**
     * Renders a sidebar navigation using custom CSS classes.
     * @param array<array<string, mixed>> $items Sidebar navigation items.
     * @param array<string, mixed> $options Configuration options:
     *   - 'title' (string|null): Sidebar title
     *   - 'collapsible' (bool): Whether sidebar can be collapsed (logic for this needs JS/CSS)
     * @return string The rendered HTML for the sidebar.
     */
    function sidebar(array $items, array $options = []): string
    {
        $title = $options['title'] ?? null;
        $collapsible = $options['collapsible'] ?? false; // Placeholder for future enhancement

        $sidebarClasses = 'sidebar';
        if ($collapsible) {
            $sidebarClasses .= ' collapsible'; // Add class if collapsible logic is implemented
        }

        $html = '<aside class="' . $sidebarClasses . '" role="navigation" aria-label="Sidebar navigation">';

        if ($title) {
            $html .= '<div class="sidebar-header p-4 border-b border-border-subtle">'; // Use padding/border classes
            $html .= '<h2 class="text-lg font-semibold text-fg">' . h($title) . '</h2>';
            $html .= '</div>';
        }

        $html .= '<nav class="sidebar-nav">'; // Use sidebar-nav class
        $html .= '<ul class="sidebar-section">'; // Use sidebar-section for spacing

        foreach ($items as $item) {
            $text = $item['text'] ?? '';
            $url = $item['url'] ?? '#';
            $icon = $item['icon'] ?? null;
            $active = $item['active'] ?? false;
            $badge = $item['badge'] ?? null; // Example: Add badge support
            $children = $item['children'] ?? [];

            $liClasses = 'sidebar-item'; // Base class for list item
            if ($active) {
                $liClasses .= ' active'; // Active state
            }
            if (!empty($children)) {
                $liClasses .= ' collapsible'; // Indicate collapsible if children exist
            }

            $html .= '<li class="' . $liClasses . '">';

            // Link or Toggle Button
            if (!empty($children)) {
                // Parent item with children - might be a toggle
                $html .= '<button type="button" class="sidebar-item-toggle flex items-center w-full gap-3 p-2 rounded-md hover:bg-bg-subtle transition-colors" aria-expanded="false">'; // Button for toggle
                if ($icon) {
                    $html .= '<i data-lucide="' . $icon . '" class="sidebar-item-icon text-fg-subtle"></i>'; // Icon
                }
                $html .= '<span class="sidebar-item-label flex-1 text-left">' . h($text) . '</span>'; // Label
                // Add chevron icon for toggle indication
                $html .= '<i data-lucide="chevron-right" class="sidebar-item-chevron w-4 h-4 text-fg-subtle transition-transform"></i>';
                $html .= '</button>';

                // Submenu
                $html .= '<ul class="sidebar-submenu mt-1 pl-6">'; // Use sidebar-submenu class with padding
                foreach ($children as $child) {
                    $childText = $child['text'] ?? '';
                    $childUrl = $child['url'] ?? '#';
                    $childActive = $child['active'] ?? false;

                    $childLinkClasses = 'sidebar-item flex items-center gap-3 p-2 rounded-md text-sm text-fg-subtle hover:text-fg hover:bg-bg-subtle transition-colors'; // Style child link
                    if ($childActive) {
                        $childLinkClasses .= ' active font-medium text-fg'; // Active child
                    }

                    $html .= '<li>';
                    $html .= '<a href="' . h($childUrl) . '" class="' . $childLinkClasses . '">' . h($childText) . '</a>';
                    $html .= '</li>';
                }
                $html .= '</ul>';

            } else {
                // Leaf item - standard link
                $linkClasses = 'sidebar-item flex items-center gap-3 p-2 rounded-md text-fg-subtle hover:text-fg hover:bg-bg-subtle transition-colors'; // Base link styles
                if ($active) {
                    $linkClasses .= ' active font-medium text-fg'; // Active state
                }

                $html .= '<a href="' . h($url) . '" class="' . $linkClasses . '">';

                if ($icon) {
                    $html .= '<i data-lucide="' . $icon . '" class="sidebar-item-icon"></i>'; // Icon
                }
                $html .= '<span class="sidebar-item-label flex-1">' . h($text) . '</span>'; // Label

                if ($badge !== null) {
                    $html .= '<span class="sidebar-item-badge bg-accent text-accent-fg text-xs font-medium rounded-full px-2 py-0.5">' . h((string) $badge) . '</span>'; // Badge
                }

                $html .= '</a>';
            }

            $html .= '</li>';
        }

        $html .= '</ul>';
        $html .= '</nav>';
        // Consider adding sidebar-footer if needed
        // $html .= '<div class="sidebar-footer">...</div>';
        $html .= '</aside>';

        return $html;
    }
}

if (!function_exists('tabs')) {
    /**
     * Renders a tab navigation component using custom CSS classes.
     * @param array<array<string, mixed>> $tabs Tab configuration array.
     * @param array<string, mixed> $options Configuration options.
     * @return string The rendered HTML for the tabs.
     */
    function tabs(array $tabs, array $options = []): string
    {
        $style = $options['style'] ?? 'underline'; // 'underline', 'pills', 'bordered'
        // Map styles to potential CSS classes or use default nav-tabs
        $navClasses = 'nav nav-tabs'; // Default tabs class
        switch ($style) {
            case 'pills':
                $navClasses .= ' nav-pills'; // Add specific class if your CSS supports it
                break;
            case 'bordered':
                $navClasses .= ' nav-bordered'; // Add specific class if your CSS supports it
                break;
            // 'underline' is default for nav-tabs
        }

        $html = '<div class="tabs-container">'; // Wrapper div
        $html .= '<nav class="' . $navClasses . '" aria-label="Tab navigation">';

        foreach ($tabs as $tab) {
            $text = $item['text'] ?? '';
            $url = $item['url'] ?? '#';
            $active = $item['active'] ?? false;
            $icon = $item['icon'] ?? null;
            $count = $item['count'] ?? null;

            $itemClasses = 'nav-item'; // Base class for tab item
            if ($active) {
                $itemClasses .= ' active'; // Active state
            }

            $html .= '<a href="' . h($url) . '" class="' . $itemClasses . '">'; // Use nav-item

            if ($icon) {
                $html .= '<i data-lucide="' . $icon . '" class="icon mr-2"></i>'; // Icon with margin
            }

            $html .= h($text);

            if ($count !== null) {
                // Use a badge-like element for count
                $countClasses = 'ml-2 bg-bg-muted text-fg-subtle text-xs font-medium rounded-full px-2 py-0.5 inline-flex items-center justify-center';
                if ($active) {
                    $countClasses = 'ml-2 bg-accent text-accent-fg text-xs font-medium rounded-full px-2 py-0.5 inline-flex items-center justify-center'; // Active style
                }
                $html .= '<span class="' . $countClasses . '">' . h((string) $count) . '</span>';
            }

            $html .= '</a>';
        }

        $html .= '</nav>';
        $html .= '</div>';

        return $html;
    }
}

if (!function_exists('dropdown')) {
    /**
     * Renders a dropdown menu using custom CSS classes.
     * Requires JavaScript to handle toggle visibility (e.g., toggle 'visible' class on .topbar-dropdown-content).
     * @param string $trigger The trigger button content.
     * @param array<array<string, mixed>> $items Dropdown menu items.
     * @param array<string, mixed> $options Configuration options.
     * @return string The rendered HTML for the dropdown.
     */
    function dropdown(string $trigger, array $items, array $options = []): string
    {
        $position = $options['position'] ?? 'bottom-left'; // bottom-left, bottom-right, top-left, top-right
        $triggerClass = $options['trigger_class'] ?? 'btn btn-ghost'; // Default trigger style
        $id = $options['id'] ?? 'dropdown-' . bin2hex(random_bytes(5)); // Better ID generation

        // Position handled via CSS or JS, class can be generic
        $wrapperClasses = 'topbar-dropdown relative'; // Use topbar-dropdown class

        $html = '<div class="' . $wrapperClasses . '">';

        // Trigger button
        $html .= '<button type="button" class="' . $triggerClass . '" id="trigger-' . $id . '" aria-haspopup="true" aria-expanded="false">';
        $html .= $trigger;
        $html .= '</button>';

        // Dropdown menu content
        $contentClasses = 'topbar-dropdown-content absolute z-dropdown mt-1 bg-bg border border-border rounded-md shadow-lg min-w-[200px] opacity-0 invisible transition-all duration-fast'; // Base classes + visibility
        // Positioning (left-0, right-0, top-full, bottom-full) often handled by CSS or JS based on 'position' var
        // Add specific positioning classes if needed or rely on JS
        $html .= '<div id="' . $id . '" class="' . $contentClasses . '" role="menu" aria-labelledby="trigger-' . $id . '">';

        $html .= '<div class="py-1">'; // Padding inside menu

        foreach ($items as $item) {
            if (($item['type'] ?? null) === 'divider') {
                $html .= '<div class="border-t border-border my-1"></div>'; // Divider
                continue;
            }

            $text = $item['text'] ?? '';
            $url = $item['url'] ?? '#';
            $icon = $item['icon'] ?? null;
            $danger = $item['danger'] ?? false;

            $linkClasses = 'block w-full text-left px-4 py-2 text-sm text-fg-subtle hover:text-fg hover:bg-bg-subtle transition-colors'; // Base item style
            if ($danger) {
                $linkClasses .= ' text-destructive hover:text-destructive-fg hover:bg-destructive'; // Danger style
            }

            $html .= '<a href="' . h($url) . '" class="' . $linkClasses . '" role="menuitem">';

            if ($icon) {
                $iconClasses = 'icon mr-2'; // Icon class with margin
                if ($danger) {
                    $iconClasses .= ' text-destructive'; // Danger icon color
                }
                $html .= '<i data-lucide="' . $icon . '" class="' . $iconClasses . '"></i>';
            }

            $html .= h($text);
            $html .= '</a>';
        }

        $html .= '</div>';
        $html .= '</div>'; // Close .topbar-dropdown-content
        $html .= '</div>'; // Close .topbar-dropdown

        return $html;
    }
}
