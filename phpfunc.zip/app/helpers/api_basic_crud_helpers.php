<?php // app/helpers/api_basic_crud_helpers.php

declare(strict_types=1);

/**
 * Generic API handler for creating records.
 * 
 * WHEN TO USE:
 * - Simple entities with straightforward validation rules
 * - Standard CRUD operations without complex business logic
 * - Entities that don't require special processing (e.g., password hashing, file uploads)
 * 
 * WHEN NOT TO USE:
 * - Complex entities with custom business logic (like users with password hashing)
 * - Entities requiring multi-table operations or transactions
 * - When you need custom validation beyond basic rules
 * - Entities with complex relationships that need special handling
 * - When audit trails, notifications, or side effects are required
 * 
 * @param array $config Configuration array:
 * - 'table' (string): The database table name
 * - 'validation_rules' (array): Validation rules for the input data
 * - 'fillable_fields' (array): Whitelist of fields that can be mass assigned
 * - 'auto_fields' (array, optional): Fields to auto-populate (e.g., timestamps, UUIDs)
 * - 'success_message' (string, optional): Custom success message
 * - 'transform_data' (callable, optional): Function to transform data before saving
 * - 'after_create' (callable, optional): Function to run after successful creation
 * 
 * @return string JSON response
 */
function api_create_handler(array $config): string
{
    try {
        // Validate required config
        if (empty($config['table']) || empty($config['validation_rules']) || empty($config['fillable_fields'])) {
            throw new InvalidArgumentException('Missing required config: table, validation_rules, or fillable_fields');
        }

        $data = input();

        // Apply validation rules
        $errors = validate($data, $config['validation_rules']);
        if (!empty($errors)) {
            return validation_error($errors);
        }

        // Prepare insert data - only include fillable fields
        $insertData = [];
        foreach ($config['fillable_fields'] as $field) {
            if (array_key_exists($field, $data)) {
                $insertData[$field] = sanitize($data[$field]);
            }
        }

        // Add auto-generated fields
        if (!empty($config['auto_fields'])) {
            foreach ($config['auto_fields'] as $field => $generator) {
                if (is_callable($generator)) {
                    $insertData[$field] = $generator();
                } else {
                    $insertData[$field] = $generator;
                }
            }
        }

        // Apply data transformation if provided
        if (isset($config['transform_data']) && is_callable($config['transform_data'])) {
            $insertData = $config['transform_data']($insertData, $data);
        }

        // Perform the insert
        $newId = table($config['table'])->insert($insertData);

        // Fetch the created record
        $newRecord = table($config['table'])->where('id', '=', $newId)->first();

        // Run after-create hook if provided
        if (isset($config['after_create']) && is_callable($config['after_create'])) {
            $config['after_create']($newRecord, $data);
        }

        $message = $config['success_message'] ?? ucfirst(str_replace('_', ' ', $config['table'])) . ' created successfully.';
        return success($newRecord, $message, 201);

    } catch (Throwable $e) {
        $tableName = $config['table'] ?? 'unknown';
        write_log("Generic Create API Error for table {$tableName}: " . $e->getMessage(), 'critical');
        return error('An internal server error occurred.', 500);
    }
}

/**
 * Generic API handler for updating records.
 * 
 * WHEN TO USE:
 * - Simple entities with standard update patterns
 * - When you don't need complex business logic or validations
 * - Straightforward field updates without side effects
 * 
 * WHEN NOT TO USE:
 * - Complex entities with custom business logic (like users with conditional password updates)
 * - When you need to validate against existing data in complex ways
 * - Entities requiring multi-table updates or transactions
 * - When you need custom authorization checks beyond basic existence
 * - Updates that trigger notifications, audit logs, or other side effects
 * 
 * @param array $config Configuration array:
 * - 'table' (string): The database table name
 * - 'id' (string): The ID of the record to update
 * - 'validation_rules' (array): Validation rules for the input data
 * - 'fillable_fields' (array): Whitelist of fields that can be updated
 * - 'auto_fields' (array, optional): Fields to auto-populate on update (e.g., updated_at)
 * - 'id_column' (string, optional): Primary key column name (defaults to 'id')
 * - 'success_message' (string, optional): Custom success message
 * - 'transform_data' (callable, optional): Function to transform data before saving
 * - 'before_update' (callable, optional): Function to run before update (for custom validation)
 * - 'after_update' (callable, optional): Function to run after successful update
 * 
 * @return string JSON response
 */
function api_update_handler(array $config): string
{
    try {
        // Validate required config
        if (empty($config['table']) || empty($config['id']) || empty($config['validation_rules']) || empty($config['fillable_fields'])) {
            throw new InvalidArgumentException('Missing required config: table, id, validation_rules, or fillable_fields');
        }

        $data = input();
        $idColumn = $config['id_column'] ?? 'id';

        // Check if record exists
        $existingRecord = table($config['table'])->where($idColumn, '=', $config['id'])->first();
        if (!$existingRecord) {
            $entityName = ucfirst(str_replace('_', ' ', $config['table']));
            return error("{$entityName} not found.", 404);
        }

        // Apply validation rules
        $errors = validate($data, $config['validation_rules']);
        if (!empty($errors)) {
            return validation_error($errors);
        }

        // Run before-update hook if provided (for custom validation)
        if (isset($config['before_update']) && is_callable($config['before_update'])) {
            $beforeResult = $config['before_update']($data, $existingRecord);
            if ($beforeResult !== true) {
                // If before_update returns something other than true, treat it as an error
                return is_string($beforeResult) ? error($beforeResult, 400) : error('Update validation failed.', 400);
            }
        }

        // Prepare update data - only include fillable fields
        $updateData = [];
        foreach ($config['fillable_fields'] as $field) {
            if (array_key_exists($field, $data)) {
                $updateData[$field] = sanitize($data[$field]);
            }
        }

        // Add auto-generated fields for updates
        if (!empty($config['auto_fields'])) {
            foreach ($config['auto_fields'] as $field => $generator) {
                if (is_callable($generator)) {
                    $updateData[$field] = $generator();
                } else {
                    $updateData[$field] = $generator;
                }
            }
        }

        // Apply data transformation if provided
        if (isset($config['transform_data']) && is_callable($config['transform_data'])) {
            $updateData = $config['transform_data']($updateData, $data, $existingRecord);
        }

        // Perform the update
        table($config['table'])->where($idColumn, '=', $config['id'])->update($updateData);

        // Fetch the updated record
        $updatedRecord = table($config['table'])->where($idColumn, '=', $config['id'])->first();

        // Run after-update hook if provided
        if (isset($config['after_update']) && is_callable($config['after_update'])) {
            $config['after_update']($updatedRecord, $existingRecord, $data);
        }

        $message = $config['success_message'] ?? ucfirst(str_replace('_', ' ', $config['table'])) . ' updated successfully.';
        return success($updatedRecord, $message);

    } catch (Throwable $e) {
        $tableName = $config['table'] ?? 'unknown';
        write_log("Generic Update API Error for table {$tableName}: " . $e->getMessage(), 'critical');
        return error('An internal server error occurred.', 500);
    }
}

/**
 * Generic API handler for deleting records.
 * 
 * WHEN TO USE:
 * - Simple entities with straightforward deletion logic
 * - When soft deletes are not required
 * - Entities without complex relationships or cascading deletes
 * - Standard delete operations without side effects
 * 
 * WHEN NOT TO USE:
 * - When you need soft deletes (marking as deleted instead of removing)
 * - Complex entities with cascade delete requirements
 * - When deletion requires special authorization (like preventing self-deletion)
 * - Entities that need to trigger notifications, cleanup tasks, or audit trails
 * - When you need to check for related records before deletion
 * - Records that should be archived instead of deleted
 * 
 * @param array $config Configuration array:
 * - 'table' (string): The database table name
 * - 'id' (string): The ID of the record to delete
 * - 'id_column' (string, optional): Primary key column name (defaults to 'id')
 * - 'success_message' (string, optional): Custom success message
 * - 'before_delete' (callable, optional): Function to run before deletion (for authorization checks)
 * - 'after_delete' (callable, optional): Function to run after successful deletion
 * - 'soft_delete' (bool, optional): Whether to use soft delete (sets deleted_at instead of removing)
 * - 'soft_delete_column' (string, optional): Column name for soft delete timestamp (defaults to 'deleted_at')
 * 
 * @return string JSON response
 */
function api_delete_handler(array $config): string
{
    try {
        // Validate required config
        if (empty($config['table']) || empty($config['id'])) {
            throw new InvalidArgumentException('Missing required config: table or id');
        }

        $idColumn = $config['id_column'] ?? 'id';

        // Check if record exists
        $existingRecord = table($config['table'])->where($idColumn, '=', $config['id'])->first();
        if (!$existingRecord) {
            $entityName = ucfirst(str_replace('_', ' ', $config['table']));
            return error("{$entityName} not found.", 404);
        }

        // Run before-delete hook if provided (for authorization or validation)
        if (isset($config['before_delete']) && is_callable($config['before_delete'])) {
            $beforeResult = $config['before_delete']($existingRecord);
            if ($beforeResult !== true) {
                // If before_delete returns something other than true, treat it as an error
                return is_string($beforeResult) ? error($beforeResult, 403) : error('Delete operation not allowed.', 403);
            }
        }

        // Perform deletion (soft or hard)
        if (!empty($config['soft_delete'])) {
            // Soft delete - update the deleted_at timestamp
            $softDeleteColumn = $config['soft_delete_column'] ?? 'deleted_at';
            $updateData = [
                $softDeleteColumn => date('Y-m-d H:i:s'),
            ];

            // Add updated_by if user is logged in
            if (function_exists('session') && session('user_id')) {
                $updateData['updated_by'] = session('user_id');
            }

            $deletedRows = table($config['table'])->where($idColumn, '=', $config['id'])->update($updateData);
        } else {
            // Hard delete - remove the record
            $deletedRows = table($config['table'])->where($idColumn, '=', $config['id'])->delete();
        }

        if ($deletedRows > 0) {
            // Run after-delete hook if provided
            if (isset($config['after_delete']) && is_callable($config['after_delete'])) {
                $config['after_delete']($existingRecord);
            }

            $message = $config['success_message'] ?? ucfirst(str_replace('_', ' ', $config['table'])) . ' deleted successfully.';
            return success(null, $message);
        }

        return error('Failed to delete record.', 500);

    } catch (Throwable $e) {
        $tableName = $config['table'] ?? 'unknown';
        write_log("Generic Delete API Error for table {$tableName}: " . $e->getMessage(), 'critical');
        return error('An internal server error occurred.', 500);
    }
}

/**
 * Example usage configurations for different scenarios:
 */

/**
 * Example: Simple category creation
 * 
 * function handle_create_category(): string
 * {
 *     return api_create_handler([
 *         'table' => 'categories',
 *         'validation_rules' => [
 *             'name' => 'required|min:3|max:100',
 *             'description' => 'max:500',
 *             'is_active' => 'boolean',
 *         ],
 *         'fillable_fields' => ['name', 'description', 'is_active'],
 *         'auto_fields' => [
 *             'id' => fn() => generate_uuidv7(),
 *             'created_at' => fn() => date('Y-m-d H:i:s'),
 *             'updated_at' => fn() => date('Y-m-d H:i:s'),
 *             'created_by' => fn() => session('user_id'),
 *             'updated_by' => fn() => session('user_id'),
 *         ],
 *     ]);
 * }
 */

/**
 * Example: Category update with custom validation
 * 
 * function handle_update_category(string $id): string
 * {
 *     return api_update_handler([
 *         'table' => 'categories',
 *         'id' => $id,
 *         'validation_rules' => [
 *             'name' => 'required|min:3|max:100',
 *             'description' => 'max:500',
 *             'is_active' => 'boolean',
 *         ],
 *         'fillable_fields' => ['name', 'description', 'is_active'],
 *         'auto_fields' => [
 *             'updated_at' => fn() => date('Y-m-d H:i:s'),
 *             'updated_by' => fn() => session('user_id'),
 *         ],
 *         'before_update' => function($newData, $existingRecord) {
 *             // Custom validation: ensure name is unique
 *             $existing = table('categories')
 *                 ->where('name', '=', $newData['name'])
 *                 ->where('id', '!=', $existingRecord['id'])
 *                 ->first();
 *             
 *             return $existing ? 'Category name already exists.' : true;
 *         },
 *     ]);
 * }
 */

/**
 * Example: Simple delete with authorization check
 * 
 * function handle_delete_tag(string $id): string
 * {
 *     return api_delete_handler([
 *         'table' => 'tags',
 *         'id' => $id,
 *         'before_delete' => function($record) {
 *             // Check if tag is still in use
 *             $inUse = table('post_tags')->where('tag_id', '=', $record['id'])->first();
 *             return $inUse ? 'Cannot delete tag that is still in use.' : true;
 *         },
 *         'after_delete' => function($deletedRecord) {
 *             // Log the deletion
 *             write_log("Tag '{$deletedRecord['name']}' was deleted by user " . session('user_id'));
 *         },
 *     ]);
 * }
 */

/**
 * Example: Soft delete configuration
 * 
 * function handle_delete_post(string $id): string
 * {
 *     return api_delete_handler([
 *         'table' => 'posts',
 *         'id' => $id,
 *         'soft_delete' => true,
 *         'soft_delete_column' => 'deleted_at',
 *         'before_delete' => function($record) {
 *             // Only allow authors or admins to delete
 *             return ($record['author_id'] === session('user_id') || session('is_admin')) 
 *                 ? true 
 *                 : 'You can only delete your own posts.';
 *         },
 *     ]);
 * }
 */

/**
 * Example: Complex entity that should NOT use generic handlers
 * 
 * // DON'T use generic handlers for users because:
 * function handle_create_user(): string
 * {
 *     // ❌ This has complex logic that doesn't fit the generic pattern:
 *     // - Password hashing
 *     // - Email uniqueness validation across updates
 *     // - Self-deletion prevention
 *     // - Role assignment logic
 *     // - Tenant-specific validation
 *     
 *     // Keep the custom implementation instead!
 * }
 */

/**
 * Utility function to create standard auto-fields for timestamps and user tracking.
 * 
 * @param bool $isUpdate Whether this is for an update operation (excludes created_* fields)
 * @return array Array of auto-field generators
 */
function standard_auto_fields(bool $isUpdate = false): array
{
    $fields = [];

    if (!$isUpdate) {
        $fields['id'] = fn() => generate_uuidv7();
        $fields['created_at'] = fn() => date('Y-m-d H:i:s');
        if (function_exists('session') && session('user_id')) {
            $fields['created_by'] = fn() => session('user_id');
        }
    }

    $fields['updated_at'] = fn() => date('Y-m-d H:i:s');
    if (function_exists('session') && session('user_id')) {
        $fields['updated_by'] = fn() => session('user_id');
    }

    return $fields;
}

/**
 * Utility function to create standard validation rules with unique email/name checks.
 * 
 * @param string $table The table name for unique validation
 * @param string|null $excludeId ID to exclude from unique checks (for updates)
 * @return array Standard validation rules
 */
function standard_validation_rules(string $table, ?string $excludeId = null): array
{
    $rules = [
        'name' => 'required|min:3|max:100',
        'description' => 'max:1000',
        'is_active' => 'boolean',
    ];

    // Add unique validation that excludes current record for updates
    if ($excludeId) {
        $rules['name'] .= "|unique:{$table},name,{$excludeId}";
    } else {
        $rules['name'] .= "|unique:{$table},name";
    }

    return $rules;
}