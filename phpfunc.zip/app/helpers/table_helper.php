<?php declare(strict_types=1);

// ===============================================
// Enhanced Table Components with Advanced Features
// ===============================================

if (!function_exists('table_wrapper_start')) {
    /**
     * Renders the responsive wrapper and opening <table> tag.
     * @param array<string, mixed> $options Configuration options.
     * @return string The opening HTML for the table wrapper.
     */
    function table_wrapper_start(array $options = []): string
    {
        $tableClasses = 'table';
        // NEW: Add layout class. Defaults to 'auto'.
        $layout = $options['layout'] ?? 'auto';
        $tableClasses .= ' table-layout-' . $layout;

        if ($options['striped'] ?? false)
            $tableClasses .= ' table-striped';
        if ($options['hoverable'] ?? true)
            $tableClasses .= ' table-hover';
        if ($options['compact'] ?? false)
            $tableClasses .= ' table-sm';
        if ($options['large'] ?? false)
            $tableClasses .= ' table-lg';
        if ($options['bordered'] ?? false)
            $tableClasses .= ' table-bordered';
        if ($options['sticky_header'] ?? false)
            $tableClasses .= ' table-sticky-header';

        return '<div class="table-wrapper"><table class="' . $tableClasses . '">';
    }
}

if (!function_exists('table_wrapper_end')) {
    /** Renders the closing tags for the table and its wrapper. */
    function table_wrapper_end(): string
    {
        return '</table></div>';
    }
}

if (!function_exists('table_head')) {
    /**
     * REVISED: Table header with specific sort trigger area and width support.
     */
    function table_head(array $headers, array $options = []): string
    {
        $selectable = $options['selectable'] ?? false;
        $popupFilters = $options['inline_filters'] ?? false;
        $html = '<thead class="bg-bg-subtle">';
        $html .= '<tr>';

        if ($selectable) {
            $html .= '<th scope="col" class="p-3 text-left w-12"> <input type="checkbox" class="form-checkbox select-all-checkbox" aria-label="Select all rows"> </th>';
        }

        foreach ($headers as $header) {
            $title = $header['title'] ?? '';
            $key = $header['key'] ?? strtolower($title);
            $sortable = $header['sortable'] ?? false;
            $filterable = ($header['filterable'] ?? false) && $popupFilters;
            $alignClass = 'text-' . ($header['align'] ?? 'left');

            // Check for width property
            $width = $header['width'] ?? null;
            $styleAttr = $width ? 'style="width: ' . h($width) . ';"' : '';

            $classes = "p-3 {$alignClass} font-weight-medium text-fg-muted uppercase";
            if ($filterable)
                $classes .= ' filterable-header';

            $html .= '<th scope="col" class="' . trim($classes) . '" ' . $styleAttr . ' data-sortable="' . ($sortable ? 'true' : 'false') . '" data-column="' . h($key) . '">';
            $html .= '<div class="header-cell-wrapper">';

            $sortTriggerAttr = $sortable ? ' data-sort-trigger="true"' : '';
            $html .= '<div class="header-content"' . $sortTriggerAttr . '><span class="header-title">' . h($title) . '</span>';
            if ($sortable) {
                $html .= '<span class="sort-icon"><ion-icon name="chevron-up-outline" class="sort-icon-up"></ion-icon><ion-icon name="chevron-down-outline" class="sort-icon-down"></ion-icon></span>';
            }
            $html .= '</div>'; // End header-content

            if ($filterable) {
                $html .= '<div class="filter-ui">';
                $html .= '<button type="button" class="filter-menu-button" aria-label="Open filter for ' . h($title) . '">';
                $html .= '<ion-icon name="filter-outline"></ion-icon>';
                $html .= '</button>';
                $html .= '<div class="filter-popup">';
                $html .= render_inline_filter_control($header);
                $html .= '</div>';
                $html .= '</div>';
            }

            $html .= '</div>';
            $html .= '</th>';
        }
        $html .= '</tr>';
        $html .= '</thead>';
        return $html;
    }
}

if (!function_exists('render_inline_filter_control')) {
    /**
     * Renders a full filter control UI inside a popup.
     */
    function render_inline_filter_control(array $column): string
    {
        $key = $column['key'] ?? '';
        $dataType = $column['filter_data_type'] ?? 'text';

        $textOps = ['contains' => 'Contains', 'notContains' => 'Not Contains', 'equals' => 'Equals', 'notEquals' => 'Not Equals', 'startsWith' => 'Starts With', 'endsWith' => 'Ends With'];
        $numberOps = ['equals' => '=', 'notEquals' => '!=', 'greaterThan' => '>', 'lessThan' => '<', 'between' => 'Between'];
        $dateOps = ['equals' => 'On', 'notEquals' => 'Not On', 'greaterThan' => 'After', 'lessThan' => 'Before', 'between' => 'Between'];

        $operators = match ($dataType) {
            'number' => $numberOps,
            'date' => $dateOps,
            default => $textOps,
        };
        $inputType = match ($dataType) {
            'number' => 'number',
            'date' => 'date',
            default => 'text',
        };

        $html = '<div class="filter-control-wrapper" data-filter-key="' . h($key) . '">';
        $html .= form_select("filters[{$key}][type]", [
            'options' => $operators,
            'attributes' => ['class' => 'form-select-sm filter-operator-select']
        ]);
        $html .= '<div class="filter-value-inputs mt-2">';
        $html .= form_input("filters[{$key}][value]", [
            'type' => $inputType,
            'placeholder' => 'Value...',
            'attributes' => ['class' => 'form-input-sm filter-value1']
        ]);
        $html .= form_input("filters[{$key}][value2]", [
            'type' => $inputType,
            'placeholder' => 'And...',
            'attributes' => ['class' => 'form-input-sm filter-value2 mt-2 hidden']
        ]);
        $html .= '</div>';

        $html .= '<div class="filter-popup-actions">';
        $html .= '<button type="button" class="btn btn-ghost btn-sm btn-icon filter-clear-btn" title="Clear filter">';
        $html .= '<ion-icon name="refresh-outline"></ion-icon>';
        $html .= '</button>';
        $html .= '<button type="button" class="btn btn-primary btn-sm btn-icon filter-apply-btn" title="Apply filter">';
        $html .= '<ion-icon name="checkmark-outline"></ion-icon>';
        $html .= '</button>';
        $html .= '</div>';

        $html .= '</div>';
        return $html;
    }
}

if (!function_exists('table_filters_bar')) {
    /**
     * Renders the main filters bar above the table.
     * @param array $filters Filter configuration array.
     * @param array<string, mixed> $options Additional options.
     * @return string The rendered filters HTML.
     */
    function table_filters_bar(array $filters, array $options = []): string
    {
        $size = $options['size'] ?? 'sm';
        $html = '<div class="table-filters-container"><div class="table-filters-bar">';
        $html .= '<div class="filters-left">';
        foreach ($filters as $filter) {
            $html .= render_filter_control($filter, ['size' => $size]);
        }
        $html .= '</div>';
        $html .= '<div class="filters-right"> <button type="button" class="btn btn-ghost btn-sm btn-icon clear-filters" title="Clear all filters" id="clear-filters-btn"> <ion-icon name="refresh-outline" class="w-4 h-4"></ion-icon> </button> </div>';
        $html .= '</div></div>';
        return $html;
    }
}

if (!function_exists('render_filter_control')) {
    /**
     * Renders individual filter control for the main filter bar.
     * @param array $filter Filter configuration.
     * @param array $options Rendering options.
     * @return string The rendered filter control HTML.
     */
    function render_filter_control(array $filter, array $options = []): string
    {
        $key = $filter['key'];
        $label = $filter['label'];
        $type = $filter['type'] ?? 'text';
        $size = $options['size'] ?? null;
        $width = $filter['width'] ?? null;
        $style_attr = $width ? 'style="width: ' . h($width) . ';"' : '';
        $size_class = $size ? " form-input-{$size}" : '';

        if ($type === 'text') {
            return '<div class="filter-control search-wrapper" ' . ($width === 'grow' ? 'style="flex: 1;"' : $style_attr) . '> <ion-icon name="search-outline" class="filter-icon"></ion-icon> <input type="text" name="' . h($key) . '" placeholder="' . h($label) . '" class="form-input' . $size_class . '"> </div>';
        }
        if ($type === 'select') {
            $html = '<div class="filter-control" ' . $style_attr . '>';
            $html .= '<select name="' . h($key) . '" class="form-select' . $size_class . '" data-filter-type="select">';
            $html .= '<option value="">All ' . h($label) . '</option>';
            foreach ($filter['options'] ?? [] as $value => $optionLabel) {
                $html .= '<option value="' . h($value) . '">' . h($optionLabel) . '</option>';
            }
            $html .= '</select></div>';
            return $html;
        }

        return '';
    }
}

if (!function_exists('table_toolbar')) {
    function table_toolbar(array $actions = [], array $options = []): string
    {
        $showSelected = $options['show_selected'] ?? true;
        $showStats = $options['show_stats'] ?? true;
        $html = '<div class="table-toolbar p-4 border-b border-border-subtle bg-bg-subtle"><div class="flex items-center justify-between gap-4">';
        $html .= '<div class="toolbar-left flex items-center gap-4">';
        if ($showSelected) {
            $html .= '<div class="selection-info hidden" id="selection-info"><span class="text-sm text-fg-muted"><span class="selected-count">0</span> item(s) selected</span></div>';
        }
        if (!empty($actions)) {
            $html .= '<div class="bulk-actions hidden flex items-center gap-2" id="bulk-actions">';
            foreach ($actions as $action) {
                $html .= button($action['label'], ['variant' => $action['variant'] ?? 'secondary', 'size' => 'sm', 'icon' => $action['icon'] ?? null, 'attributes' => ['data-action' => $action['key'], 'class' => 'bulk-action']]);
            }
            $html .= '</div>';
        }
        $html .= '</div>';
        $html .= '<div class="toolbar-right flex items-center gap-4">';
        if ($showStats) {
            $html .= '<div class="table-stats text-sm text-fg-muted"><span id="table-stats">Loading...</span></div>';
        }
        $html .= '</div></div></div>';
        return $html;
    }
}

if (!function_exists('table_pagination')) {
    function table_pagination(array $pagination, array $options = []): string
    {
        $currentPage = $pagination['current_page'] ?? 1;
        $totalPages = $pagination['last_page'] ?? 1;
        $totalItems = $pagination['total'] ?? 0;
        $perPage = $pagination['per_page'] ?? 10;

        if ($totalItems === 0)
            return '';

        $html = '<div class="table-pagination p-4 border-t border-border-subtle bg-bg-subtle"><div class="flex items-center justify-between gap-4">';
        $html .= '<div class="pagination-left flex items-center gap-4">';
        $html .= '<div class="page-size-selector flex items-center gap-2"><label class="text-sm text-fg-muted">Show:</label><select class="form-select form-input-sm w-auto page-size-select">';
        foreach ([10, 25, 50, 100] as $size) {
            $html .= '<option value="' . $size . '"' . ($perPage == $size ? ' selected' : '') . '>' . $size . '</option>';
        }
        $html .= '</select></div>';

        $startItem = ($currentPage - 1) * $perPage + 1;
        $endItem = min($currentPage * $perPage, $totalItems);
        $html .= '<div class="pagination-info text-sm text-fg-muted">Showing ' . number_format($startItem) . ' to ' . number_format($endItem) . ' of ' . number_format($totalItems) . ' results</div>';
        $html .= '</div>';
        $html .= '<div class="pagination-right">' . render_pagination_controls($currentPage, $totalPages) . '</div>';
        $html .= '</div></div>';
        return $html;
    }
}

if (!function_exists('render_pagination_controls')) {
    function render_pagination_controls(int $currentPage, int $totalPages): string
    {
        if ($totalPages <= 1)
            return '';
        $html = '<nav class="pagination-nav"><ul class="flex items-center gap-1">';
        $html .= '<li><button type="button" class="pagination-btn' . ($currentPage <= 1 ? ' disabled' : '') . '" data-page="' . ($currentPage - 1) . '"><ion-icon name="chevron-back-outline" class="w-4 h-4"></ion-icon></button></li>';
        $start = max(1, $currentPage - 2);
        $end = min($totalPages, $currentPage + 2);
        if ($start > 1) {
            $html .= '<li><button type="button" class="pagination-btn" data-page="1">1</button></li>';
            if ($start > 2)
                $html .= '<li><span class="pagination-ellipsis">…</span></li>';
        }
        for ($i = $start; $i <= $end; $i++) {
            $html .= '<li><button type="button" class="pagination-btn' . ($i === $currentPage ? ' active' : '') . '" data-page="' . $i . '">' . $i . '</button></li>';
        }
        if ($end < $totalPages) {
            if ($end < $totalPages - 1)
                $html .= '<li><span class="pagination-ellipsis">…</span></li>';
            $html .= '<li><button type="button" class="pagination-btn" data-page="' . $totalPages . '">' . $totalPages . '</button></li>';
        }
        $html .= '<li><button type="button" class="pagination-btn' . ($currentPage >= $totalPages ? ' disabled' : '') . '" data-page="' . ($currentPage + 1) . '"><ion-icon name="chevron-forward-outline" class="w-4 h-4"></ion-icon></button></li>';
        $html .= '</ul></nav>';
        return $html;
    }
}

if (!function_exists('table_empty_state')) {
    function table_empty_state(string $message = 'No data available', array $options = []): string
    {
        $colspan = $options['colspan'] ?? 1;
        return '<tr class="empty-state"><td colspan="' . $colspan . '" class="p-12 text-center"><div class="flex flex-col items-center max-w-sm mx-auto"><div class="empty-icon mb-4"><ion-icon name="' . h($options['icon'] ?? 'mail') . '" class="w-16 h-16 text-fg-muted"></ion-icon></div><h3 class="text-lg font-weight-medium text-fg mb-2">' . h($message) . '</h3></div></td></tr>';
    }
}

if (!function_exists('render_advanced_table')) {
    /**
     * Renders a complete table, intelligently combining the main filter bar and inline header filters.
     * @param string $id Unique table identifier.
     * @param array $config Complete table configuration.
     * @return string The rendered HTML for the complete table component.
     */
    function render_advanced_table(string $id, array $config): string
    {
        $columns = $config['columns'] ?? [];
        $features = $config['features'] ?? [];
        $hasSelection = $features['selection'] ?? false;
        $colspan = count($columns) + ($hasSelection ? 1 : 0);
        $tableLayout = $config['layout'] ?? 'auto'; // <-- NEW: Get layout option

        $html = '<div id="' . h($id) . '" class="table-component advanced-table" data-dynamic-table="true">';

        if (!empty($config['filters'])) {
            $html .= table_filters_bar($config['filters'], $config['filter_options'] ?? []);
        }

        $html .= '<div class="table-loading-overlay hidden"><div class="loading-spinner"><ion-icon name="reload-outline" class="w-8 h-8 animate-spin text-accent"></ion-icon></div></div>';

        // --- MODIFIED: Pass layout option to table_wrapper_start ---
        $tableOptions = array_merge($config['table_options'] ?? [], ['layout' => $tableLayout]);
        $html .= table_wrapper_start($tableOptions);

        $html .= table_head($columns, [
            'selectable' => $hasSelection,
            'inline_filters' => $features['inline_filters'] ?? false,
        ]);
        $html .= '<tbody>' . table_empty_state($config['emptyMessage'] ?? 'No records found', ['colspan' => $colspan]) . '</tbody>';
        $html .= table_wrapper_end();

        if ($features['pagination'] ?? true) {
            $html .= '<div class="pagination-container"></div>';
        }

        $html .= '<script type="application/json" class="table-config">' . json_encode($config) . '</script>';

        $html .= '</div>';
        return $html;
    }
}