<?php
// app/helpers/vw_form_helpers.php
declare(strict_types=1);

if (!function_exists('form_input')) {
    /**
     * Renders a form input field.
     *
     * @param string $name The name attribute of the input.
     * @param array $options Configuration options:
     *   - 'type' (string): Input type (text, email, password, etc.). Default 'text'.
     *                     Hidden inputs are handled separately.
     *   - 'label' (string): The label text. Default ''.
     *   - 'value' (string): The initial value. Default ''.
     *   - 'placeholder' (string): Placeholder text. Default ''.
     *   - 'required' (bool): Whether the field is required. Default false.
     *   - 'disabled' (bool): Whether the field is disabled. Default false.
     *   - 'error' (string|null): Error message to display. Default null.
     *   - 'help_text' (string|null): Help/description text. Default null.
     *   - 'size' (string|null): Size variant (e.g., 'sm'). Default null.
     *   - 'prefix' (string|null): Icon or text to display before the input. Default null.
     *   - 'suffix' (string|null): Icon or text to display after the input. Default null.
     *   - 'attributes' (array): Additional HTML attributes. Default [].
     * @return string The rendered HTML for the form group.
     */
    function form_input(string $name, array $options = []): string
    {
        $type = $options['type'] ?? 'text';
        if ($type === 'hidden') {
            $attributes = array_merge([
                'type' => 'hidden',
                'name' => $name,
                'value' => $options['value'] ?? ''
            ], $options['attributes'] ?? []);
            return '<input ' . build_attributes($attributes) . '>';
        }

        $label = $options['label'] ?? '';
        $error = $options['error'] ?? null;
        $id = $options['attributes']['id'] ?? 'form-' . preg_replace('/[^a-zA-Z0-9\-_]/', '-', $name); // Sanitize ID
        $required = $options['required'] ?? false;
        $helpText = $options['help_text'] ?? null;
        $size = $options['size'] ?? null;
        $prefix = $options['prefix'] ?? null;
        $suffix = $options['suffix'] ?? null;

        // --- Label Classes ---
        $labelClasses = ['form-label'];
        if ($required) {
            $labelClasses[] = 'form-label-required';
        }

        // --- Input Classes ---
        $inputClasses = ['form-input'];
        if ($error) {
            $inputClasses[] = 'form-input-error';
        }
        if ($size) {
            $inputClasses[] = 'form-input-' . $size; // e.g., 'form-input-sm'
        }
        // Add classes for prefix/suffix if present
        if ($prefix) {
            $inputClasses[] = 'has-prefix';
        }
        if ($suffix) {
            $inputClasses[] = 'has-suffix';
        }

        // --- Input Attributes ---
        $attributes = array_merge([
            'type' => $type,
            'name' => $name,
            'id' => $id,
            'class' => implode(' ', $inputClasses),
            'value' => $options['value'] ?? '',
            'placeholder' => $options['placeholder'] ?? ''
        ], $options['attributes'] ?? []);

        if ($required) {
            $attributes['required'] = true;
        }
        if ($options['disabled'] ?? false) {
            $attributes['disabled'] = true;
        }

        // --- Build HTML ---
        $html = '<div class="form-group">';

        if ($label) {
            $html .= '<label for="' . h($id) . '" class="' . implode(' ', $labelClasses) . '">' . h($label) . '</label>';
        }

        // Wrap input in a group if prefix or suffix is used
        if ($prefix || $suffix) {
            $html .= '<div class="form-input-group">';
            if ($prefix) {
                $html .= '<span class="form-input-prefix">' . $prefix . '</span>';
            }
            $html .= '<input ' . build_attributes($attributes) . '>';
            if ($suffix) {
                $html .= '<span class="form-input-suffix">' . $suffix . '</span>';
            }
            $html .= '</div>';
        } else {
            // Standard input without group
            $html .= '<input ' . build_attributes($attributes) . '>';
        }

        if ($error) {
            $html .= '<p class="form-error">' . h($error) . '</p>';
        } elseif ($helpText) {
            $html .= '<p class="form-description">' . h($helpText) . '</p>';
        }
        $html .= '</div>';

        return $html;
    }
}

if (!function_exists('form_checkbox')) {
    /**
     * Renders a checkbox field.
     * FINAL FIX: The label content is no longer escaped with h(), allowing it
     * to render HTML passed from the calling view.
     *
     * @param string $name The name attribute of the checkbox.
     * @param array $options Configuration options.
     * @return string The rendered HTML for the checkbox group.
     */
    function form_checkbox(string $name, array $options = []): string
    {
        $label = $options['label'] ?? '';
        $id = $options['attributes']['id'] ?? 'form-' . preg_replace('/[^a-zA-Z0-9\-_]/', '-', $name . '-checkbox' . uniqid()); // Ensure unique ID
        $checked = $options['checked'] ?? false;
        $disabled = $options['disabled'] ?? false;
        $value = $options['value'] ?? '1';

        $attributes = array_merge([
            'type' => 'checkbox',
            'name' => $name,
            'id' => $id,
            'class' => 'form-checkbox',
            'value' => $value,
        ], $options['attributes'] ?? []);

        if ($checked) {
            $attributes['checked'] = true;
        }
        if ($disabled) {
            $attributes['disabled'] = true;
        }

        $html = '<div class="form-checkbox-group">';
        $html .= '<input ' . build_attributes($attributes) . '>';
        if ($label) {
            $label_classes = ['form-checkbox-label'];
            if ($disabled) {
                $label_classes[] = 'form-checkbox-label-disabled';
            }
            // --- THIS IS THE FIX ---
            // The h() function has been removed from around $label to allow HTML rendering.
            $html .= '<label for="' . h($id) . '" class="' . implode(' ', $label_classes) . '">' . $label . '</label>';
        }
        $html .= '</div>';
        return $html;
    }
}

// Consider adding form_radio, form_select, form_toggle, form_file helpers following similar patterns
// They would use classes like form-radio, form-select, form-toggle, form-file-group, form-file-button etc.

if (!function_exists('form_textarea')) {
    /**
     * Renders a textarea field.
     *
     * @param string $name The name attribute of the textarea.
     * @param array $options Configuration options:
     *   - 'label' (string): The label text. Default ''.
     *   - 'value' (string): The initial value. Default ''.
     *   - 'placeholder' (string): Placeholder text. Default ''.
     *   - 'rows' (int): Number of rows. Default 4.
     *   - 'required' (bool): Whether the field is required. Default false.
     *   - 'disabled' (bool): Whether the field is disabled. Default false.
     *   - 'error' (string|null): Error message to display. Default null.
     *   - 'help_text' (string|null): Help/description text. Default null.
     *   - 'attributes' (array): Additional HTML attributes. Default [].
     * @return string The rendered HTML for the form group.
     */
    function form_textarea(string $name, array $options = []): string
    {
        $label = $options['label'] ?? '';
        $error = $options['error'] ?? null;
        $id = $options['attributes']['id'] ?? 'form-' . preg_replace('/[^a-zA-Z0-9\-_]/', '-', $name . '-textarea'); // Unique ID for textarea
        $required = $options['required'] ?? false;
        $helpText = $options['help_text'] ?? null;
        $value = $options['value'] ?? '';

        // --- Label Classes ---
        $labelClasses = ['form-label'];
        if ($required) {
            $labelClasses[] = 'form-label-required';
        }

        // --- Textarea Classes ---
        $textareaClasses = ['form-input', 'form-textarea']; // Includes base form-input class
        if ($error) {
            $textareaClasses[] = 'form-input-error';
        }

        // --- Textarea Attributes ---
        $attributes = array_merge([
            'name' => $name,
            'id' => $id,
            'class' => implode(' ', $textareaClasses),
            'rows' => $options['rows'] ?? 4,
            'placeholder' => $options['placeholder'] ?? ''
        ], $options['attributes'] ?? []);

        if ($required) {
            $attributes['required'] = true;
        }
        if ($options['disabled'] ?? false) {
            $attributes['disabled'] = true;
        }

        // --- Build HTML ---
        $html = '<div class="form-group">';
        if ($label) {
            $html .= '<label for="' . h($id) . '" class="' . implode(' ', $labelClasses) . '">' . h($label) . '</label>';
        }
        // Note the placement of the closing tag and value
        $html .= '<textarea ' . build_attributes($attributes) . '>' . h($value) . '</textarea>';
        if ($error) {
            $html .= '<p class="form-error">' . h($error) . '</p>';
        } elseif ($helpText) {
            $html .= '<p class="form-description">' . h($helpText) . '</p>';
        }
        $html .= '</div>';
        return $html;
    }
}

// Example of adding a Select helper (following the pattern)
if (!function_exists('form_select')) {
    /**
     * Renders a select dropdown field.
     *
     * @param string $name The name attribute of the select.
     * @param array $options Configuration options:
     *   - 'label' (string): The label text. Default ''.
     *   - 'options' (array): Associative array of value => label for select options.
     *   - 'selected' (string|array): The selected value(s). Default ''.
     *   - 'placeholder' (string): Placeholder/blank option text. Default ''.
     *   - 'multiple' (bool): Whether multiple selections are allowed. Default false.
     *   - 'required' (bool): Whether the field is required. Default false.
     *   - 'disabled' (bool): Whether the field is disabled. Default false.
     *   - 'error' (string|null): Error message to display. Default null.
     *   - 'help_text' (string|null): Help/description text. Default null.
     *   - 'size' (string|null): Size variant (e.g., 'sm'). Default null.
     *   - 'attributes' (array): Additional HTML attributes. Default [].
     * @return string The rendered HTML for the form group.
     */
    function form_select(string $name, array $options = []): string
    {
        $label = $options['label'] ?? '';
        $selectOptions = $options['options'] ?? [];
        $selected = $options['selected'] ?? '';
        $placeholder = $options['placeholder'] ?? '';
        $multiple = $options['multiple'] ?? false;
        $error = $options['error'] ?? null;
        $id = $options['attributes']['id'] ?? 'form-' . preg_replace('/[^a-zA-Z0-9\-_]/', '-', $name . '-select');
        $required = $options['required'] ?? false;
        $helpText = $options['help_text'] ?? null;
        $size = $options['size'] ?? null;
        $disabled = $options['disabled'] ?? false;

        // --- Label Classes ---
        $labelClasses = ['form-label'];
        if ($required) {
            $labelClasses[] = 'form-label-required';
        }

        // --- Select Classes ---
        $selectClasses = ['form-select'];
        if ($error) {
            $selectClasses[] = 'form-input-error'; // Reuse error class
        }
        if ($size) {
            $selectClasses[] = 'form-input-' . $size; // Reuse size class pattern
        }

        // --- Select Attributes ---
        $attributes = array_merge([
            'name' => $name . ($multiple ? '[]' : ''), // Add [] for multiple
            'id' => $id,
            'class' => implode(' ', $selectClasses),
        ], $options['attributes'] ?? []);

        if ($multiple) {
            $attributes['multiple'] = true;
        }
        if ($required) {
            $attributes['required'] = true;
        }
        if ($disabled) {
            $attributes['disabled'] = true;
        }

        // --- Build HTML ---
        $html = '<div class="form-group">';
        if ($label) {
            $html .= '<label for="' . h($id) . '" class="' . implode(' ', $labelClasses) . '">' . h($label) . '</label>';
        }

        $html .= '<select ' . build_attributes($attributes) . '>';

        // Placeholder option
        if ($placeholder !== '') {
            $html .= '<option value="" disabled ' . (empty($selected) ? 'selected' : '') . '>' . h($placeholder) . '</option>';
        }

        // Options
        foreach ($selectOptions as $value => $label) {
            $isSelected = $multiple ? in_array($value, (array) $selected) : $value == $selected;
            $html .= '<option value="' . h($value) . '"' . ($isSelected ? ' selected' : '') . '>' . h($label) . '</option>';
        }

        $html .= '</select>';

        if ($error) {
            $html .= '<p class="form-error">' . h($error) . '</p>';
        } elseif ($helpText) {
            $html .= '<p class="form-description">' . h($helpText) . '</p>';
        }
        $html .= '</div>';
        return $html;
    }
}