<?php

/**
 * app/helpers/utilities.php - Utility Functions
 *
 * This file contains various utility helper functions for string manipulation,
 * arrays, file sizes, and general application logic.
 */

declare(strict_types=1);

/**
 * Generate a URL-friendly "slug" from a given string.
 *
 * @param string $string The string to slugify.
 * @param string $separator The separator to use between words.
 * @return string The slugified string.
 */
function str_slug(string $string, string $separator = '-'): string
{
    // Convert to lowercase
    $string = mb_strtolower($string, 'UTF-8');
    // Transliterate characters to ASCII
    $string = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
    // Remove characters that are not letters, numbers, spaces, or hyphens
    $string = preg_replace('/[^a-z0-9\s-]/', '', $string);
    // Replace spaces and multiple hyphens with a single separator
    $string = preg_replace('/[\s-]+/', $separator, trim($string));
    return $string;
}

/**
 * Limit the number of characters in a string.
 *
 * @param string $string The input string.
 * @param int $limit The maximum number of characters.
 * @param string $end The string to append if truncated.
 * @return string The truncated string.
 */
function str_limit(string $string, int $limit = 100, string $end = '...'): string
{
    if (mb_strlen($string) <= $limit) {
        return $string;
    }
    return rtrim(mb_substr($string, 0, $limit, 'UTF-8')) . $end;
}

/**
 * Format phone number to E.164 international format (e.g., +14155552671).
 *
 * @param string $phone The phone number to format.
 * @return string The formatted phone number.
 */
function format_phone_number(string $phone): string
{
    // Remove all non-digit characters
    $phone = preg_replace('/\D/', '', $phone);

    // If it starts with a country code already, just ensure the '+' is there
    if (strlen($phone) > 10) {
        return '+' . ltrim($phone, '+');
    }

    // A simple assumption for US numbers if no country code is provided.
    if (strlen($phone) === 10) {
        return '+1' . $phone;
    }

    // For other cases, just prepend '+'
    return '+' . $phone;
}

/**
 * Format file size into a human-readable string.
 *
 * @param int $bytes The file size in bytes.
 * @param int $precision The number of decimal places.
 * @return string The formatted file size.
 */
function format_file_size(int $bytes, int $precision = 2): string
{
    if ($bytes <= 0) {
        return '0 B';
    }
    $units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    $power = floor(log($bytes, 1024));
    return round($bytes / (1024 ** $power), $precision) . ' ' . $units[$power];
}

/**
 * Converts a datetime string to a human-readable "time ago" format.
 *
 * @param string $datetime The datetime string to compare.
 * @return string The time ago string.
 */
function time_ago(string $datetime): string
{
    try {
        $time = time() - (new DateTimeImmutable($datetime))->getTimestamp();

        if ($time < 1) {
            return 'just now';
        }

        $time_formats = [
            31536000 => 'year',
            2592000 => 'month',
            86400 => 'day',
            3600 => 'hour',
            60 => 'minute',
            1 => 'second'
        ];

        foreach ($time_formats as $seconds => $unit) {
            $division = $time / $seconds;
            if ($division >= 1) {
                $value = floor($division);
                return "{$value} {$unit}" . ($value > 1 ? 's' : '') . ' ago';
            }
        }
        return 'just now';
    } catch (Exception) {
        return $datetime;
    }
}

/**
 * Get an item from an array using "dot" notation.
 *
 * @param array<string, mixed> $array The array to search in.
 * @param string|null $key The key to retrieve (e.g., 'user.name').
 * @param mixed $default The default value if the key is not found.
 * @return mixed The found value or the default.
 */
function array_get(array $array, ?string $key, mixed $default = null): mixed
{
    if ($key === null) {
        return $array;
    }
    if (isset($array[$key])) {
        return $array[$key];
    }
    foreach (explode('.', $key) as $segment) {
        if (!is_array($array) || !array_key_exists($segment, $array)) {
            return $default;
        }
        $array = $array[$segment];
    }
    return $array;
}

/**
 * Check if the application is in debug mode.
 *
 * @return bool True if debug mode is enabled.
 */
function is_debug(): bool
{
    return (bool) config('app.debug', false);
}