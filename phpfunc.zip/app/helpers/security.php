<?php

// ================================

// app/helpers/security.php - Security Functions
/**
 * Security helper functions
 */

/**
 * Generate CSRF token
 */
function csrf_token()
{
    if (!session_has('_csrf_token')) {
        session_put('_csrf_token', bin2hex(random_bytes(32)));
    }

    return session('_csrf_token');
}

/**
 * Verify CSRF token
 */
function verify_csrf($token)
{
    return hash_equals(session('_csrf_token', ''), $token);
}

/**
 * Hash password
 */
function hash_password($password)
{
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Verify password
 */
function verify_password($password, $hash)
{
    return password_verify($password, $hash);
}

/**
 * Generate random string
 */
function random_string($length = 32)
{
    return bin2hex(random_bytes($length / 2));
}

/**
 * Encrypt data
 */
function encrypt($data, $key = null)
{
    $key = $key ?: env('APP_KEY');

    if (!$key) {
        throw new Exception('Encryption key not set');
    }

    $iv = random_bytes(16);
    $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);

    return base64_encode($iv . $encrypted);
}

/**
 * Decrypt data
 */
function decrypt($encrypted_data, $key = null)
{
    $key = $key ?: env('APP_KEY');

    if (!$key) {
        throw new Exception('Encryption key not set');
    }

    $data = base64_decode($encrypted_data);
    $iv = substr($data, 0, 16);
    $encrypted = substr($data, 16);

    return openssl_decrypt($encrypted, 'AES-256-CBC', $key, 0, $iv);
}

/**
 * Rate limiting
 */
function rate_limit($key, $max_attempts = 60, $decay_minutes = 1)
{
    $cache_key = "rate_limit:{$key}";
    $attempts = cache_get($cache_key, 0);

    if ($attempts >= $max_attempts) {
        return false;
    }

    cache_put($cache_key, $attempts + 1, $decay_minutes * 60);
    return true;
}

/**
 * Get rate limit remaining attempts
 */
function rate_limit_remaining($key, $max_attempts = 60)
{
    $cache_key = "rate_limit:{$key}";
    $attempts = cache_get($cache_key, 0);

    return max(0, $max_attempts - $attempts);
}