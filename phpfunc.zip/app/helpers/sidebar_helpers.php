<?php // app/helpers/sidebar_helpers.php
declare(strict_types=1);

// This helper gets the current URL path for active state checking.
if (!function_exists('get_current_path')) {
    function get_current_path(): string
    {
        return parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
    }
}


if (!function_exists('render_sidebar_brand')) {
    function render_sidebar_brand(array $brand_config = []): string
    {
        $brand_name = h($brand_config['name'] ?? 'PHP Func');
        $brand_icon = h($brand_config['icon'] ?? 'cube-outline');
        $brand_url = h($brand_config['url'] ?? '/dashboard');

        return <<<HTML
<a href="{$brand_url}" class="sidebar-brand">
    <ion-icon name="{$brand_icon}" class="sidebar-brand-icon"></ion-icon>
    <span class="sidebar-text">{$brand_name}</span>
</a>
HTML;
    }
}

if (!function_exists('render_menu_item')) {
    function render_menu_item(array $item, string $current_path): string
    {
        $state = is_menu_item_active($item, $current_path);
        $link_class = 'nav-link' . ($state['is_active'] || $state['is_parent_of_active_child'] ? ' is-active' : '');
        $slug = h($item['slug']);
        $href = $state['has_children'] ? '/' . h($item['children'][0]['slug']) : '/' . $slug;

        $html = '<li class="nav-item">';
        $html .= '<a href="' . $href . '" class="' . $link_class . '">';
        $html .= '<ion-icon name="' . h($item['icon']) . '" class="nav-icon"></ion-icon>';
        $html .= '<span class="sidebar-text">' . h($item['text']) . '</span>';
        if ($state['has_children']) {
            $html .= '<ion-icon name="chevron-down-outline" class="sidebar-text nav-chevron"></ion-icon>';
        }
        $html .= '</a>';

        if ($state['has_children'] && $state['is_parent_of_active_child']) {
            $html .= '<ul class="nav-submenu">';
            foreach ($item['children'] as $child) {
                $child_slug_path = '/' . h($child['slug']);
                $child_active = ($child_slug_path === $current_path) ? 'is-active' : '';
                $html .= '<li><a href="' . $child_slug_path . '" class="nav-link ' . $child_active . '">' . h($child['text']) . '</a></li>';
            }
            $html .= '</ul>';
        }

        $html .= '</li>';
        return $html;
    }
}

function render_full_sidebar(array $menu, array $brand_config = []): string
{
    $current_path = get_current_path();

    // --- Sidebar Header (Brand) ---
    $brand_name = h($brand_config['name'] ?? 'App');
    $brand_url = h($brand_config['url'] ?? '/');
    $header_html = <<<HTML
<div class="sidebar-header">
    <a href="{$brand_url}">
        <div class="sidebar-logo">
            <span>{$brand_name[0]}</span>
        </div>
        <h2>{$brand_name}</h2>
    </a>
</div>
HTML;

    // --- Sidebar Navigation ---
    $nav_html = '<div class="sidebar-nav-wrapper"><nav class="sidebar-nav">';
    foreach ($menu as $section) {
        if (!empty($section['is_heading'])) {
            $nav_html .= '<div class="sidebar-section">';
            // MODIFIED LINE: Added data-tooltip attribute
            $nav_html .= '<h3 class="sidebar-section-title" data-tooltip="' . h($section['text']) . '">' . h($section['text']) . '</h3>';

            if (!empty($section['children'])) {
                foreach ($section['children'] as $item) {
                    $slug = $item['slug'] ?? '#';
                    $url = '/' . ltrim($slug, '/');
                    $is_active = ($url === $current_path);
                    $active_class = $is_active ? ' active' : '';
                    $icon = $item['icon'] ?? null;
                    $text = h($item['text']);
                    // Add tooltip data attribute for collapsed state
                    $tooltip_attr = 'data-tooltip="' . $text . '"';

                    $nav_html .= '<div class="sidebar-item">';
                    $nav_html .= '<a href="' . h($url) . '" class="sidebar-item-content' . $active_class . '" ' . $tooltip_attr . '>';
                    if ($icon) {
                        $nav_html .= '<span class="sidebar-item-icon"><ion-icon name="' . h($icon) . '"></ion-icon></span>';
                    }
                    $nav_html .= '<span class="sidebar-item-label">' . $text . '</span>';
                    $nav_html .= '</a>';
                    $nav_html .= '</div>';
                }
            }
            $nav_html .= '</div>';
        }
    }
    $nav_html .= '</nav></div>';

    // --- Sidebar Footer (Toggle Button) ---
    $footer_html = <<<HTML
<div class="sidebar-footer">
    <button id="sidebar-toggle" class="sidebar-toggle-btn" data-tooltip="Collapse Sidebar">
        <span class="sidebar-item-icon">
            <!-- Note: Icons are swapped via CSS for better performance -->
            <ion-icon name="chevron-back-outline" class="toggle-icon toggle-icon-expand"></ion-icon>
            <ion-icon name="chevron-forward-outline" class="toggle-icon toggle-icon-collapse"></ion-icon>
        </span>
        <span class="sidebar-item-label">Collapse</span>
    </button>
</div>
HTML;


    // --- Final Assembly ---
    return <<<HTML
<aside class="sidebar" id="main-sidebar">
    {$header_html}
    {$nav_html}
    {$footer_html}
</aside>
HTML;
}


if (!function_exists('render_app_sidebar')) {
    function render_app_sidebar(array $menu, bool $is_collapsed = false, array $brand_config = []): string
    {
        return render_full_sidebar($menu, $brand_config);
    }
}