<?php // app/helpers/api_helpers.php

declare(strict_types=1);

/**
 * Creates a standardized API response for paginated lists.
 * This function now handles a global search term AND column-specific inline filters.
 *
 * @param array $config The configuration for the list endpoint.
 * - 'base_query' (QueryBuilder): The initial QueryBuilder instance.
 * - 'searchable_columns' (array): Columns for the global 'search' parameter.
 * - 'filterable_columns' (array): Whitelist of columns for inline header filters (e.g., 'filter_name').
 * - 'sortable_columns' (array): A whitelist of columns allowed for sorting.
 * - 'default_sort' (array): ['column' => string, 'direction' => 'asc|desc'].
 * @return string The JSON response.
 */
function api_list_handler(array $config): string
{
    try {
        $page = (int) (input('page', 1));
        $perPage = (int) (input('per_page', 10));
        $sortDir = in_array(strtolower(input('sort_dir', '')), ['asc', 'desc']) ? input('sort_dir') : $config['default_sort']['direction'];
        $sortByInput = input('sort_by', $config['default_sort']['column']);
        $sortBy = in_array($sortByInput, $config['sortable_columns']) ? $sortByInput : $config['default_sort']['column'];

        // --- REVISED: Get search and filters separately ---
        $globalSearch = input('search', '');
        $advancedFilters = input('filters', []); // This specifically looks for the 'filters' array

        $query = $config['base_query'];

        // --- Apply Global Search (from main search bar) ---
        if (!empty($globalSearch) && !empty($config['searchable_columns'])) {
            $query->where(function ($q) use ($globalSearch, $config) {
                foreach ($config['searchable_columns'] as $column) {
                    $q->orWhere($column, 'LIKE', "%{$globalSearch}%");
                }
            });
        }

        // --- Apply Advanced Column-Specific Filters ---
        if (!empty($advancedFilters) && is_array($advancedFilters)) {
            foreach ($advancedFilters as $column => $filter) {
                // Ensure the column is actually filterable
                if (!in_array($column, $config['filterable_columns'] ?? []))
                    continue;

                $type = $filter['type'] ?? 'contains';
                $value = $filter['value'] ?? null;
                $value2 = $filter['value2'] ?? null;

                if ($value === null || $value === '')
                    continue;

                switch ($type) {
                    case 'equals':
                        $query->where($column, '=', $value);
                        break;
                    case 'notEquals':
                        $query->where($column, '!=', $value);
                        break;
                    case 'contains':
                        $query->where($column, 'LIKE', '%' . $value . '%');
                        break;
                    case 'notContains':
                        $query->where($column, 'NOT LIKE', '%' . $value . '%');
                        break;
                    case 'startsWith':
                        $query->where($column, 'LIKE', $value . '%');
                        break;
                    case 'endsWith':
                        $query->where($column, 'LIKE', '%' . $value);
                        break;
                    case 'greaterThan':
                        $query->where($column, '>', $value);
                        break;
                    case 'greaterThanOrEqual':
                        $query->where($column, '>=', $value);
                        break;
                    case 'lessThan':
                        $query->where($column, '<', $value);
                        break;
                    case 'lessThanOrEqual':
                        $query->where($column, '<=', $value);
                        break;
                    case 'between':
                        if ($value2 !== null && $value2 !== '') {
                            $query->whereBetween($column, $value, $value2);
                        }
                        break;
                }
            }
        }

        // --- Apply Sorting ---
        if ($sortBy && $sortDir) {
            $query->orderBy($sortBy, $sortDir);
        }

        $paginatedData = $query->paginate($perPage, $page);

        return success($paginatedData, 'Data fetched successfully.');
    } catch (Throwable $e) {
        write_log("API List Handler Error: " . $e->getMessage(), 'critical');
        return error('An internal server error occurred.', 500);
    }
}


/**
 * Creates a standardized API response for fetching a single record by ID.
 * @param array $config Configuration for the get endpoint.
 * @return string The JSON response.
 */
function api_get_handler(array $config): string
{
    try {
        $idColumn = $config['id_column'] ?? 'id';
        $record = table($config['table'])->where($idColumn, '=', $config['id'])->first();

        if (!$record) {
            return error(ucfirst(str_replace('_', ' ', $config['table'])) . ' not found.', 404);
        }

        if (isset($config['security_check']) && is_callable($config['security_check'])) {
            if (!$config['security_check']($record)) {
                return error('Forbidden.', 403);
            }
        }

        if (!empty($config['relations'])) {
            foreach ($config['relations'] as $relationName => $relationConfig) {
                $record[$relationName] = array_column(
                    table($relationConfig['pivot_table'])
                        ->where($relationConfig['foreign_key'], '=', $config['id'])
                        ->get(),
                    $relationConfig['related_key']
                );
            }
        }

        if (!empty($config['fields_to_unset'])) {
            foreach ($config['fields_to_unset'] as $field) {
                unset($record[$field]);
            }
        }

        return success($record);
    } catch (Throwable $e) {
        write_log("API Get Handler Error for table {$config['table']}: " . $e->getMessage(), 'critical');
        return error('An internal server error occurred.', 500);
    }
}