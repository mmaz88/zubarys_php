<?php

declare(strict_types=1);

/**
 * View Helper Functions
 * Basic helpers for HTML, CSS, JS with timestamp support.
 */


if (!function_exists('h')) {
    /**
     * Escapes a string for secure output in HTML.
     * Handles strings, arrays, objects, and null values.
     *
     * @param string|array<mixed>|object|null $string The input to escape.
     * @param int $flags A bitmask of one or more of the ENT_* flags.
     * @param string $encoding The encoding to use.
     * @param bool $double_encode Whether to encode existing HTML entities.
     * @return string The escaped string.
     */
    function h(string|array|object|null $string, int $flags = ENT_QUOTES, string $encoding = 'UTF-8', bool $double_encode = true): string
    {
        if ($string === null) {
            return '';
        }
        if (is_array($string) || is_object($string)) {
            return htmlspecialchars(json_encode($string), $flags, $encoding, $double_encode);
        }
        return htmlspecialchars((string) $string, $flags, $encoding, $double_encode);
    }
}

/**
 * Generates a <link> tag for a CSS file with cache-busting timestamp.
 *
 * @param string $file The path to the CSS file (e.g., 'styles.css' or a full URL).
 * @param array<string, mixed> $attributes Additional HTML attributes for the tag.
 * @return string The generated HTML <link> tag.
 */
function css(string $file, array $attributes = []): string
{
    $url = asset($file, 'assets/css', 'css');
    $attrs = array_merge([
        'rel' => 'stylesheet',
        'type' => 'text/css',
        'href' => $url
    ], $attributes);
    return '<link ' . build_attributes($attrs) . '>';
}

/**
 * Generates multiple CSS <link> tags.
 *
 * @param array<string> $files An array of CSS file paths.
 * @param array<string, mixed> $attributes Additional HTML attributes for the tags.
 * @return string The generated HTML.
 */
function css_files(array $files, array $attributes = []): string
{
    $output = array_map(fn($file) => css($file, $attributes), $files);
    return implode("\n", $output);
}

/**
 * Generates a <script> tag for a JavaScript file with cache-busting timestamp.
 *
 * @param string $file The path to the JS file (e.g., 'app.js' or a full URL).
 * @param array<string, mixed> $attributes Additional HTML attributes for the tag.
 * @return string The generated HTML <script> tag.
 */
function js(string $file, array $attributes = []): string
{
    $url = asset($file, 'assets/js', 'js');
    $attrs = array_merge([
        'type' => 'text/javascript',
        'src' => $url
    ], $attributes);
    return '<script ' . build_attributes($attrs) . '></script>';
}

/**
 * Generates multiple JavaScript <script> tags.
 *
 * @param array<string> $files An array of JS file paths.
 * @param array<string, mixed> $attributes Additional HTML attributes for the tags.
 * @return string The generated HTML.
 */
function js_files(array $files, array $attributes = []): string
{
    $output = array_map(fn($file) => js($file, $attributes), $files);
    return implode("\n", $output);
}

/**
 * Generates an <img> tag with a cache-busting timestamp.
 *
 * @param string $file The path to the image file (e.g., 'logo.png' or a full URL).
 * @param string $alt The alt text for the image.
 * @param array<string, mixed> $attributes Additional HTML attributes for the tag.
 * @return string The generated HTML <img> tag.
 */
function img(string $file, string $alt = '', array $attributes = []): string
{
    $url = asset($file, 'assets/images');
    $attrs = array_merge([
        'src' => $url,
        'alt' => h($alt)
    ], $attributes);
    return '<img ' . build_attributes($attrs) . '>';
}

/**
 * Generates a URL for an asset file with an optional cache-busting timestamp.
 *
 * @param string $file The path to the asset file.
 * @param string|null $defaultDir The default directory prefix if not present in the file path.
 * @param string|null $extension The default file extension if not present.
 * @return string The full asset URL.
 */
function asset(string $file, ?string $defaultDir = null, ?string $extension = null): string
{
    $file = ltrim($file, '/');
    if (preg_match('/^https?:\/\//', $file)) {
        return $file;
    }

    $base_url = get_base_url();

    if ($defaultDir && !str_starts_with($file, 'assets/')) {
        $file = $defaultDir . '/' . $file;
    }

    if ($extension && !str_ends_with($file, '.' . $extension)) {
        $file .= '.' . $extension;
    }

    $url = $base_url . '/' . $file;

    if (should_add_timestamp()) {
        $file_path = PUBLIC_PATH . '/' . $file;
        if (file_exists($file_path)) {
            $timestamp = filemtime($file_path);
            $url .= '?v=' . $timestamp;
        }
    }

    return $url;
}

/**
 * Gets the base URL of the application.
 * Caches the result for subsequent calls.
 *
 * @return string The base URL.
 */
function get_base_url(): string
{
    static $base_url = null;

    if ($base_url === null) {
        $base_url = rtrim(env('APP_URL', ''), '/');
        if (empty($base_url)) {
            $protocol = is_secure() ? 'https' : 'http';
            $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
            $base_url = $protocol . '://' . $host;
        }
    }

    return $base_url;
}

/**
 * Determines if a cache-busting timestamp should be added to asset URLs.
 * Timestamps are added in non-production environments or when debug mode is on.
 *
 * @return bool True if timestamp should be added, false otherwise.
 */
function should_add_timestamp(): bool
{
    $env = env('APP_ENV', 'production');
    $debug = env('APP_DEBUG', false);

    return $env !== 'production' || $debug === true;
}

/**
 * Builds an HTML attributes string from an associative array.
 *
 * @param array<string, mixed> $attributes The attributes array.
 * @return string The HTML attribute string.
 */
function build_attributes(array $attributes): string
{
    $html = [];
    foreach ($attributes as $key => $value) {
        if (is_bool($value)) {
            if ($value) {
                $html[] = $key;
            }
        } elseif ($value !== null) {
            $html[] = $key . '="' . h((string) $value) . '"';
        }
    }
    return implode(' ', $html);
}

/**
 * Generates a <link> tag for a favicon.
 *
 * @param string $file The path to the favicon file.
 * @param string|null $type The MIME type of the icon. Auto-detected if null.
 * @return string The HTML <link> tag.
 */
function favicon(string $file = 'favicon.ico', ?string $type = null): string
{
    $url = asset($file);
    if ($type === null) {
        $extension = pathinfo($file, PATHINFO_EXTENSION);
        $type = match (strtolower($extension)) {
            'png' => 'image/png',
            'jpg', 'jpeg' => 'image/jpeg',
            'gif' => 'image/gif',
            'svg' => 'image/svg+xml',
            default => 'image/x-icon',
        };
    }
    return '<link rel="icon" type="' . h($type) . '" href="' . h($url) . '">';
}

/**
 * Generates a <meta> tag.
 *
 * @param string $name The name or property of the meta tag.
 * @param string $content The content of the meta tag.
 * @param string $type The attribute to use for the name ('name' or 'property').
 * @return string The generated HTML <meta> tag.
 */
function meta(string $name, string $content, string $type = 'name'): string
{
    return '<meta ' . $type . '="' . h($name) . '" content="' . h($content) . '">';
}

/**
 * Generates meta tags for Open Graph protocol.
 *
 * @param array<string, string> $data Associative array of OG properties and content.
 * @return string The generated HTML meta tags.
 */
function og_tags(array $data): string
{
    $output = [];
    foreach ($data as $property => $content) {
        $output[] = meta('og:' . $property, $content, 'property');
    }
    return implode("\n", $output);
}

/**
 * Generates a hidden input field.
 *
 * @param string $name The name of the input field.
 * @param string $value The value of the input field.
 * @return string The HTML hidden input field.
 */
function hidden_input(string $name, string $value): string
{
    return '<input type="hidden" name="' . h($name) . '" value="' . h($value) . '">';
}

/**
 * Generates a hidden input field for CSRF protection.
 *
 * @return string The HTML hidden input field.
 */
function csrf_field(): string
{
    return hidden_input('_csrf_token', csrf_token());
}

/**
 * Generates a hidden input field to override the form method (e.g., for PUT or DELETE).
 *
 * @param string $method The HTTP method (e.g., 'PUT', 'DELETE').
 * @return string The HTML hidden input field.
 */
function method_field(string $method): string
{
    return hidden_input('_method', strtoupper($method));
}

/**
 * Formats a number as currency.
 * Requires the `intl` PHP extension for full functionality.
 *
 * @param float|int $amount The numeric amount.
 * @param string $currency The 3-letter ISO currency code (e.g., 'USD').
 * @param string $locale The locale for formatting (e.g., 'en_US').
 * @return string The formatted currency string.
 */
function currency(float|int $amount, string $currency = 'USD', string $locale = 'en_US'): string
{
    if (class_exists('NumberFormatter')) {
        $formatter = new NumberFormatter($locale, NumberFormatter::CURRENCY);
        return $formatter->formatCurrency($amount, $currency);
    }
    // Fallback if intl extension is not available
    return $currency . ' ' . number_format((float) $amount, 2);
}

/**
 * Formats a number with grouped thousands.
 *
 * @param float|int $number The number to format.
 * @param int $decimals The number of decimal points.
 * @return string The formatted number.
 */
function number_format_helper(float|int $number, int $decimals = 0): string
{
    return number_format((float) $number, $decimals);
}

/**
 * Formats a date/time value.
 *
 * @param string|int|DateTimeInterface $date The date to format (string, timestamp, or DateTime object).
 * @param string $format The desired output format (see date() function).
 * @return string The formatted date string.
 */
function format_date(string|int|DateTimeInterface $date, string $format = 'Y-m-d H:i:s'): string
{
    try {
        if ($date instanceof DateTimeInterface) {
            return $date->format($format);
        }
        if (is_numeric($date)) {
            $dt = new DateTimeImmutable('@' . $date);
            return $dt->format($format);
        }
        $dt = new DateTimeImmutable($date);
        return $dt->format($format);
    } catch (Exception $e) {
        // In case of any error, return the original input
        write_log("Date formatting failed for value: {$date}. Error: " . $e->getMessage(), 'warning');
        return (string) $date;
    }
}

/**
 * Generates pagination links.
 *
 * @param int $current_page The current active page.
 * @param int $total_pages The total number of pages.
 * @param string $base_url The base URL for page links.
 * @param int $show_pages The number of page links to show around the current page.
 * @return string The generated HTML for pagination.
 */
function paginate(int $current_page, int $total_pages, string $base_url, int $show_pages = 5): string
{
    if ($total_pages <= 1) {
        return '';
    }

    $html = '<nav class="pagination">';
    $url_separator = str_contains($base_url, '?') ? '&' : '?';

    // Previous button
    if ($current_page > 1) {
        $html .= '<a href="' . $base_url . $url_separator . 'page=' . ($current_page - 1) . '" class="pagination-prev">&laquo; Previous</a>';
    }

    // Page numbers logic
    $start = max(1, $current_page - (int) floor($show_pages / 2));
    $end = min($total_pages, $start + $show_pages - 1);

    if ($end - $start + 1 < $show_pages) {
        $start = max(1, $end - $show_pages + 1);
    }

    if ($start > 1) {
        $html .= '<a href="' . $base_url . $url_separator . 'page=1" class="pagination-link">1</a>';
        if ($start > 2) {
            $html .= '<span class="pagination-ellipsis">...</span>';
        }
    }

    for ($page = $start; $page <= $end; $page++) {
        if ($page === $current_page) {
            $html .= '<span class="pagination-link pagination-current">' . $page . '</span>';
        } else {
            $html .= '<a href="' . $base_url . $url_separator . 'page=' . $page . '" class="pagination-link">' . $page . '</a>';
        }
    }

    if ($end < $total_pages) {
        if ($end < $total_pages - 1) {
            $html .= '<span class="pagination-ellipsis">...</span>';
        }
        $html .= '<a href="' . $base_url . $url_separator . 'page=' . $total_pages . '" class="pagination-link">' . $total_pages . '</a>';
    }

    // Next button
    if ($current_page < $total_pages) {
        $html .= '<a href="' . $base_url . $url_separator . 'page=' . ($current_page + 1) . '" class="pagination-next">Next &raquo;</a>';
    }

    $html .= '</nav>';
    return $html;
}