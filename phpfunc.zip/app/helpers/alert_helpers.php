<?php
// app/helpers/components/alerts.php
declare(strict_types=1);

if (!function_exists('alert')) {
    /**
     * Prepare an alert to be sent to the modern alert system.
     *
     * @param string $message The alert message.
     * @param array $options An array of options.
     * @return string A JSON string representing the alert configuration.
     */
    function alert(string $message, array $options = []): string
    {
        $config = [
            'message' => $message,
            'variant' => $options['variant'] ?? 'success',
            'title' => $options['title'] ?? null,
            'position' => $options['position'] ?? 'bottom-right', // top-right, top-center, bottom-center
            'duration' => $options['duration'] ?? 5000, // in milliseconds
            'autoClose' => $options['autoClose'] ?? true,
        ];

        // Filter out null values for a cleaner JSON output
        $config = array_filter($config, fn($value) => !is_null($value));

        return json_encode($config);
    }
}

if (!function_exists('toast')) {
    /**
     * Prepare a toast notification.
     *
     * @param string $message The toast message.
     * @param array $options An array of options.
     * @return string A JSON string for the toast.
     */
    function toast(string $message, array $options = []): string
    {
        $defaults = [
            'position' => 'top-right',
            'duration' => 3000,
        ];
        return alert($message, array_merge($defaults, $options));
    }
}