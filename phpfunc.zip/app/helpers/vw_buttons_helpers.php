<?php
// app/helpers/vw_buttons_helpers.php
declare(strict_types=1);

if (!function_exists('button')) {
    /**
     * Renders a button or anchor tag using the design system classes.
     *
     * @param string $content The text or HTML content inside the button.
     * @param array<string, mixed> $options Configuration options.
     *   - 'variant' (string): Button style (e.g., 'primary', 'secondary', 'ghost'). Default 'primary'.
     *   - 'size' (string|null): Button size (e.g., 'sm', 'lg', 'xl'). Default null.
     *   - 'href' (string|null): If provided, renders an <a> tag. Default null (renders <button>).
     *   - 'icon' (string|null): Name of an icon (e.g., for ion-icon). Default null.
     *   - 'icon_position' (string): 'before' or 'after' content. Default 'before'.
     *   - 'disabled' (bool): Whether the button is disabled. Default false.
     *   - 'loading' (bool): Whether to show a loading spinner. Default false.
     *   - 'type' (string|null): Type attribute for <button> (e.g., 'submit', 'button'). Default 'submit' for buttons, ignored for links.
     *   - 'attributes' (array): Additional HTML attributes (e.g., 'id', 'data-*'). Default [].
     * @return string The rendered HTML for the button/link.
     */
    function button(string $content, array $options = []): string
    {
        $defaults = [
            'variant' => 'primary',
            'size' => null,
            'href' => null,
            'icon' => null,
            'icon_position' => 'before',
            'disabled' => false,
            'loading' => false,
            'type' => null,
            'attributes' => [],
        ];

        $config = array_merge($defaults, $options);
        $tag = $config['href'] ? 'a' : 'button';

        // Start with attributes from the 'attributes' key
        $attributes = $config['attributes'];

        // --- Class Name Generation ---
        $classes = ['btn', 'btn-' . $config['variant']];
        if ($config['size']) {
            $classes[] = 'btn-' . $config['size'];
        }
        // Check for icon-only button (no text content)
        if ($config['icon'] && empty(trim(strip_tags($content)))) {
            $classes[] = 'btn-icon';
        }
        if ($config['loading']) {
            $classes[] = 'btn-loading'; // Apply loading class
        }
        if (!empty($attributes['class'])) {
            $classes[] = $attributes['class'];
        }
        $attributes['class'] = implode(' ', array_unique(array_filter($classes)));

        // --- Attribute Merging ---
        if ($tag === 'button') {
            // Prioritize the 'type' from options, then default to 'submit' if not set for forms.
            $attributes['type'] = $config['type'] ?? 'submit';
        } else { // It's an 'a' tag
            $attributes['href'] = $config['href'];
        }

        if ($config['disabled']) {
            $attributes['disabled'] = true;
            // Ensure aria-disabled is also set for links
            if ($tag === 'a') {
                $attributes['aria-disabled'] = 'true';
                // Optionally remove href for truly disabled links
                // unset($attributes['href']);
            }
        }

        // --- Inner Content Generation ---
        $iconHtml = $config['icon'] ? '<ion-icon name="' . h($config['icon']) . '"></ion-icon>' : '';
        $contentHtml = trim($content) ? '<span>' . $content . '</span>' : '';

        // If loading, content is hidden by CSS (color: transparent), so iconHtml is sufficient
        if ($config['loading']) {
            $innerContent = $iconHtml; // Spinner is handled by CSS ::after
        } else {
            $innerContent = ($config['icon_position'] === 'before') ? $iconHtml . $contentHtml : $contentHtml . $iconHtml;
        }

        return "<{$tag} " . build_attributes($attributes) . ">{$innerContent}</{$tag}>";
    }
}

if (!function_exists('icon_button')) {
    /**
     * Renders an icon-only button.
     *
     * @param string $icon The name of the icon.
     * @param array $options Configuration options for the button.
     *   - 'variant' (string): Button style. Default 'ghost'.
     *   - 'size' (string|null): Button size. Default null.
     *   - 'href' (string|null): If provided, renders an <a> tag. Default null.
     *   - 'disabled' (bool): Whether the button is disabled. Default false.
     *   - 'loading' (bool): Whether to show a loading spinner. Default false.
     *   - 'type' (string): Type attribute for <button>. Default 'button'.
     *   - 'attributes' (array): Additional HTML attributes. Default [].
     *     Default 'aria-label' is set based on the icon name.
     * @return string The rendered HTML for the icon button.
     */
    function icon_button(string $icon, array $options = []): string
    {
        $defaults = [
            'variant' => 'ghost',
            'size' => null,
            'href' => null,
            'disabled' => false,
            'loading' => false,
            'type' => 'button', // Icon buttons should default to 'button' type
            'attributes' => ['aria-label' => ucfirst(str_replace(['-', '_'], ' ', $icon))], // Improve aria-label generation
        ];
        // Merge attributes properly, don't overwrite the default aria-label unless explicitly provided
        $userAttributes = $options['attributes'] ?? [];
        $mergedAttributes = array_merge($defaults['attributes'], $userAttributes);
        $options['attributes'] = $mergedAttributes;

        $config = array_merge($defaults, $options);
        $config['icon'] = $icon;
        // Ensure content is empty for icon-only button
        return button('', $config);
    }
}