<?php

function generate_uuidv4(): string
{
    $data = random_bytes(16);

    // Set version to 0100 (UUIDv4)
    $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
    // Set variant to 10xx
    $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);

    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}
function generate_uuidv7(): string
{
    // Get current time in milliseconds
    $ms = (int) floor(microtime(true) * 1000);

    // Convert timestamp to 6-byte hex (48 bits)
    $timeHex = str_pad(dechex($ms), 12, "0", STR_PAD_LEFT);

    // Generate 10 random bytes (20 hex chars)
    $randomHex = bin2hex(random_bytes(10));

    // Assemble UUIDv7
    $hex = $timeHex . $randomHex;

    // Insert dashes in UUID format: 8-4-4-4-12
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(substr($hex, 0, 32), 4));
}