<?php // app/helpers/layout_helpers.php
declare(strict_types=1);

// --- Core Helpers (Unchanged) ---
if (!function_exists('is_menu_item_active')) {
    // This function will now use the actual URL path instead of a GET parameter.
    function is_menu_item_active(array $item, string $current_path): array
    {
        $has_children = !empty($item['children']);
        $is_parent_of_active_child = false;
        $item_slug_path = '/' . ($item['slug'] ?? '');

        if ($has_children) {
            foreach ($item['children'] as $child) {
                if ('/' . ($child['slug'] ?? '') === $current_path) {
                    $is_parent_of_active_child = true;
                    break;
                }
            }
        }

        return [
            'is_active' => !$has_children && ($item_slug_path === $current_path),
            'is_parent_of_active_child' => $is_parent_of_active_child,
            'has_children' => $has_children
        ];
    }
}


// --- Header Component Functions (Refactored) ---

if (!function_exists('render_theme_toggle')) {
    function render_theme_toggle(): string
    {
        // Using button and icon classes from your CSS
        return <<<HTML
<button data-theme-toggle type="button" class="btn btn-ghost btn-sm" aria-label="Switch theme">
    <ion-icon data-sun-icon name="sunny-outline" class="icon"></ion-icon>
    <ion-icon data-moon-icon name="moon-outline" class="icon"></ion-icon>
</button>
HTML;
    }
}


if (!function_exists('render_user_dropdown')) {
    /**
     * Renders the user menu for the TOP BAR.
     *
     * @param array $user_data Associative array with user 'name', 'avatar', and optionally 'role'.
     * @return string The rendered HTML for the top bar user menu.
     */
    function render_user_dropdown(array $user_data = []): string
    {
        $user_name = h($user_data['name'] ?? 'Admin User');
        $user_role = h($user_data['role'] ?? 'Administrator'); // Example role
        $user_avatar_url = h($user_data['avatar'] ?? 'https://i.pravatar.cc/150?u=admin');
        $initials = strtoupper(substr($user_name, 0, 1));

        return <<<HTML
<div class="topbar-user">
    <div class="topbar-user-avatar">
        <img src="{$user_avatar_url}" alt="User Avatar">
    </div>
    <div class="topbar-user-info">
        <div class="topbar-user-name">{$user_name}</div>
        <div class="topbar-user-role">{$user_role}</div>
    </div>
</div>
HTML;
    }
}


if (!function_exists('render_app_header')) {
    /**
     * Renders the application header (topbar) with correct structure.
     *
     * @param string $page_title The main title for the current page.
     * @param array $user_data Associative array containing user information.
     * @param array $breadcrumbs Associative array for breadcrumb navigation.
     * @return string The rendered HTML for the application header.
     */
    function render_app_header(string $page_title, array $user_data = [], array $breadcrumbs = []): string
    {
        $theme_toggle_html = render_theme_toggle();
        $user_dropdown_html = render_user_dropdown($user_data);

        // --- Generate Breadcrumb HTML (if provided) ---
        $breadcrumbs_html = '';
        if (!empty($breadcrumbs)) {
            // Add a visual separator for clarity
            $breadcrumbs_html = '<div class="topbar-title-separator"></div>' . breadcrumb($breadcrumbs);
        }

        // --- Build Main Header HTML ---
        $html = <<<HTML
<header class="topbar">
    <div class="topbar-content">
        <!-- Left Section: Title and Breadcrumbs -->
        <div class="topbar-left">
           
            <div class="topbar-title-area">
                <h1 class="topbar-title">{$page_title}</h1>
                {$breadcrumbs_html}
            </div>
        </div>
        <!-- Right Section: Actions and User Menu -->
        <div class="topbar-right">
            <div class="topbar-actions">
                {$theme_toggle_html}
            </div>
            <div class="topbar-dropdown">
                <!-- Wrapper for the user menu -->
                {$user_dropdown_html}
            </div>
        </div>
    </div>
</header>
HTML;

        return $html;
    }
}