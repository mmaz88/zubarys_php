<?php // app/api/system/UserApi.php

declare(strict_types=1);

/**
 * Handles listing users with server-side pagination, searching, and sorting.
 * MODIFIED: Now supports both global search and specific inline column filters.
 */
function handle_list_users(): string
{
    $config = [
        'base_query' => table('users')
            ->select([
                'users.id',
                'users.name',
                'users.email',
                'users.is_tenant_admin',
                'users.created_at',
                'tenants.name as tenant_name'
            ])
            ->leftJoin('tenants', 'users.tenant_id', '=', 'tenants.id'),
        // For the main search bar
        'searchable_columns' => ['users.name', 'users.email', 'tenants.name'],
        // For the new AG Grid-style header filters
        'filterable_columns' => ['users.name', 'users.email', 'tenants.name'],
        'sortable_columns' => ['users.name', 'users.email', 'users.created_at', 'tenants.name'],
        'default_sort' => ['column' => 'users.created_at', 'direction' => 'DESC'],
    ];

    return api_list_handler($config);
}

/**
 * Handles fetching a single user and their associated role names for the view page.
 * REWRITTEN: This function is now specific and does not use the generic handler to
 * provide richer data, including a list of role names.
 */
function handle_get_user(string $id): string
{
    try {
        $user = table('users')
            ->select(['users.*', 'tenants.name as tenant_name'])
            ->leftJoin('tenants', 'users.tenant_id', '=', 'tenants.id')
            ->where('users.id', '=', $id)
            ->first();

        if (!$user) {
            return error('User not found.', 404);
        }

        // Fetch the names of the roles assigned to the user
        $roles = table('roles')
            ->select('roles.name')
            ->join('user_roles', 'roles.id', '=', 'user_roles.role_id')
            ->where('user_roles.user_id', '=', $id)
            ->orderBy('roles.name', 'ASC')
            ->get();

        // Attach the role names to the user object
        $user['roles'] = array_column($roles, 'name');

        // Always remove the password hash from the response
        unset($user['password']);

        return success($user);
    } catch (Throwable $e) {
        write_log("Get User API Error: " . $e->getMessage(), 'critical');
        return error('An internal server error occurred.', 500);
    }
}


/**
 * Handles creating a new user.
 */
function handle_create_user(): string
{
    try {
        $data = input();
        $rules = [
            'name' => 'required|min:3|max:100',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:8',
            'tenant_id' => 'required|exists:tenants,id',
        ];

        $errors = validate($data, $rules);
        if (!empty($errors)) {
            return validation_error($errors);
        }

        $userId = generate_uuidv7();
        $currentTime = date('Y-m-d H:i:s');
        $insertData = [
            'id' => $userId,
            'name' => sanitize($data['name']),
            'email' => sanitize($data['email']),
            'password' => hash_password($data['password']),
            'tenant_id' => $data['tenant_id'],
            'is_tenant_admin' => !empty($data['is_tenant_admin']),
            'created_by' => session('user_id'),
            'updated_by' => session('user_id'),
            'created_at' => $currentTime,
            'updated_at' => $currentTime,
        ];

        table('users')->insert($insertData);

        $newUser = table('users')->where('id', '=', $userId)->first();
        unset($newUser['password']);
        return success($newUser, 'User created successfully.', 201);
    } catch (Throwable $e) {
        write_log("User Create API Error: " . $e->getMessage(), 'critical');
        return error('An internal server error occurred.', 500);
    }
}

/**
 * Handles updating an existing user.
 */
function handle_update_user(string $id): string
{
    try {
        $data = input();
        $rules = [
            'name' => 'required|min:3|max:100',
            'email' => 'required|email',
            'tenant_id' => 'required|exists:tenants,id',
        ];
        if (!empty($data['password'])) {
            $rules['password'] = 'min:8';
        }

        $errors = validate($data, $rules);
        if (!empty($errors)) {
            return validation_error($errors);
        }

        if (!table('users')->where('id', '=', $id)->first()) {
            return error('User not found.', 404);
        }

        $existingEmail = table('users')
            ->where('email', '=', $data['email'])
            ->where('id', '!=', $id)
            ->first();
        if ($existingEmail) {
            return validation_error(['email' => 'The email has already been taken.']);
        }

        $updateData = [
            'name' => sanitize($data['name']),
            'email' => sanitize($data['email']),
            'tenant_id' => $data['tenant_id'],
            'is_tenant_admin' => !empty($data['is_tenant_admin']),
            'updated_by' => session('user_id'),
            'updated_at' => date('Y-m-d H:i:s'),
        ];
        if (!empty($data['password'])) {
            $updateData['password'] = hash_password($data['password']);
        }

        table('users')->where('id', '=', $id)->update($updateData);

        $updatedUser = table('users')->where('id', '=', $id)->first();
        unset($updatedUser['password']);
        return success($updatedUser, 'User updated successfully.');
    } catch (Throwable $e) {
        write_log("User Update API Error: " . $e->getMessage(), 'critical');
        return error('An internal server error occurred.', 500);
    }
}

/**
 * Handles deleting a user.
 */
function handle_delete_user(string $id): string
{
    try {
        if ($id === session('user_id')) {
            return error('You cannot delete your own account.', 409);
        }
        if (!table('users')->where('id', '=', $id)->first()) {
            return error('User not found.', 404);
        }

        $deletedRows = table('users')->where('id', '=', $id)->delete();
        if ($deletedRows > 0) {
            return success(null, 'User deleted successfully.');
        }
        return error('Failed to delete user.', 500);
    } catch (Throwable $e) {
        write_log("User Delete API Error: " . $e->getMessage(), 'critical');
        return error('An internal server error occurred.', 500);
    }
}