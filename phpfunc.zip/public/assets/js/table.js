// FILE: public/assets/js/table.js

class DynamicTable {
  /**
   * A static registry for custom cell rendering functions.
   * New renderers can be added from other scripts using DynamicTable.addRenderer().
   */
  static renderers = {
    default: (value) =>
      value !== null && value !== undefined
        ? App.escapeHTML(String(value))
        : "",
    date: (value) => (value ? new Date(value).toLocaleDateString() : ""),
  };

  static addRenderer(name, func) {
    DynamicTable.renderers[name] = func;
  }

  constructor(element) {
    if (!element) throw new Error("DynamicTable requires a valid DOM element.");
    this.element = element;
    const configScript = this.element.querySelector(
      'script[type="application/json"]'
    );
    if (!configScript)
      throw new Error("DynamicTable configuration script not found.");

    this.config = JSON.parse(configScript.textContent);
    this.table = this.element.querySelector(".table");
    this.thead = this.table.querySelector("thead");
    this.tbody = this.table.querySelector("tbody");
    this.paginationContainer = this.element.querySelector(
      ".pagination-container"
    );

    /**
     * The single source of truth for the table's current state.
     * All data fetching and rendering is driven by this object.
     */
    this.state = {
      page: 1,
      per_page: this.config.pageSize || 10,
      sortBy: this.config.defaultSort?.column || null,
      sortDir: this.config.defaultSort?.direction || "desc",
      filters: {
        global: {}, // For the main search bar, e.g., { search: "query" }
        advanced: {}, // For column popups, e.g., { "users.name": { type, value, value2 } }
      },
    };

    this.activeFilterPopup = null;
    this.handleEscKey = this._handleEscKey.bind(this);
    this.handleClickOutside = this._handleClickOutside.bind(this);

    this.element.dynamicTableInstance = this; // Make instance accessible from the element
    this.init();
  }

  init() {
    this.initEventListeners();
    this.fetchData();
  }

  refresh() {
    this.fetchData();
  }

  /**
   * Sets up all event listeners for the component.
   */
  initEventListeners() {
    // A single, delegated click handler for efficiency
    this.element.addEventListener("click", this._handleClicks.bind(this));

    // Handle interactions with the main filter bar above the table
    const mainFilterBar = this.element.querySelector(".table-filters-bar");
    if (mainFilterBar) {
      const debouncedApply = App.debounce(() => this.applyFilters(), 400);
      mainFilterBar.addEventListener("input", (e) => {
        if (e.target.matches('input[type="text"]')) {
          debouncedApply();
        }
      });
      mainFilterBar.addEventListener("change", (e) => {
        if (e.target.matches("select")) {
          this.applyFilters();
        }
      });
    }

    // Handle the show/hide logic for the second input in 'between' filters
    if (this.thead) {
      this.thead.addEventListener("change", (e) => {
        if (e.target.classList.contains("filter-operator-select")) {
          const parent = e.target.closest(".filter-control-wrapper");
          const value2Input = parent.querySelector(".filter-value2");
          value2Input.classList.toggle("hidden", e.target.value !== "between");
        }
      });
    }
  }

  /**
   * Central click handler to delegate actions within the component.
   */
  _handleClicks(e) {
    const sortTrigger = e.target.closest('[data-sort-trigger="true"]');
    const filterButton = e.target.closest(".filter-menu-button");
    const applyButton = e.target.closest(".filter-apply-btn");
    const clearButton = e.target.closest(".filter-clear-btn");
    const clearAllButton = e.target.closest(".clear-filters");
    const paginationButton = e.target.closest(".pagination-btn");

    if (sortTrigger) this.handleSort(sortTrigger);
    if (filterButton) this.toggleFilterPopup(filterButton);
    if (applyButton) this.applyPopupFilter(applyButton);
    if (clearButton) this.clearPopupFilter(clearButton);
    if (clearAllButton) this.clearAllFilters();
    if (paginationButton && !paginationButton.disabled) {
      this.state.page = parseInt(paginationButton.dataset.page);
      this.fetchData();
    }
  }

  handleSort(sortTrigger) {
    const th = sortTrigger.closest("th");
    const columnKey = th.dataset.column;
    if (this.state.sortBy === columnKey) {
      this.state.sortDir = this.state.sortDir === "asc" ? "desc" : "asc";
    } else {
      this.state.sortBy = columnKey;
      this.state.sortDir = "asc";
    }
    this.thead
      .querySelectorAll("th")
      .forEach((h) => h.classList.remove("sort-asc", "sort-desc"));
    th.classList.add(`sort-${this.state.sortDir}`);
    this.fetchData();
  }

  /**
   * The main function to trigger a data refresh based on current filter state.
   */
  applyFilters() {
    this.state.page = 1;
    this.updateFilterState();
    this.fetchData();
  }

  /**
   * Gathers all filter values from the DOM and updates the central state object.
   */
  updateFilterState() {
    this.state.filters.global = {};
    this.state.filters.advanced = {};

    const mainSearch = this.element.querySelector('[name="search"]');
    if (mainSearch && mainSearch.value) {
      this.state.filters.global.search = mainSearch.value;
    }

    this.thead
      .querySelectorAll(".filter-control-wrapper")
      .forEach((wrapper) => {
        const key = wrapper.dataset.filterKey;
        const value1 = wrapper.querySelector(".filter-value1").value;

        if (key && value1) {
          const type = wrapper.querySelector(".filter-operator-select").value;
          const value2 = wrapper.querySelector(".filter-value2").value;
          this.state.filters.advanced[key] = { type, value: value1 };
          if (type === "between" && value2) {
            this.state.filters.advanced[key].value2 = value2;
          }
        }
      });

    this.updateFilterIcons();
  }

  /**
   * Updates the UI to show a blue icon on columns with active filters.
   */
  updateFilterIcons() {
    this.thead.querySelectorAll(".filterable-header").forEach((th) => {
      const key = th.dataset.column;
      const button = th.querySelector(".filter-menu-button");
      if (button) {
        const isFilterActive = !!this.state.filters.advanced[key];
        button.classList.toggle("active-filter", isFilterActive);
      }
    });
  }

  toggleFilterPopup(button) {
    const popup = button.nextElementSibling;
    if (!popup) return;
    if (popup === this.activeFilterPopup) {
      this.closeFilterPopup();
    } else {
      if (this.activeFilterPopup) this.closeFilterPopup();
      this.openFilterPopup(popup);
    }
  }

  openFilterPopup(popup) {
    this.activeFilterPopup = popup;
    this.element.classList.add("filter-popup-open"); // Allows popup to overflow
    popup.classList.add("visible");
    popup.previousElementSibling.classList.add("active");

    document.addEventListener("keydown", this.handleEscKey);
    document.addEventListener("mousedown", this.handleClickOutside, true);

    setTimeout(() => popup.querySelector("input, select")?.focus(), 50);
  }

  closeFilterPopup() {
    if (!this.activeFilterPopup) return;
    this.element.classList.remove("filter-popup-open"); // Restores scroll clipping
    this.activeFilterPopup.classList.remove("visible");
    this.activeFilterPopup.previousElementSibling.classList.remove("active");
    document.removeEventListener("keydown", this.handleEscKey);
    document.removeEventListener("mousedown", this.handleClickOutside, true);
    this.activeFilterPopup = null;
  }

  _handleEscKey(e) {
    if (e.key === "Escape") this.closeFilterPopup();
  }
  _handleClickOutside(e) {
    if (this.activeFilterPopup && !e.target.closest(".filter-ui"))
      this.closeFilterPopup();
  }

  applyPopupFilter() {
    this.applyFilters();
    this.closeFilterPopup();
  }

  clearPopupFilter(button) {
    const wrapper = button.closest(".filter-control-wrapper");
    if (!wrapper) return;
    wrapper.querySelectorAll("input").forEach((input) => (input.value = ""));
    wrapper.querySelectorAll("select").forEach((select) => {
      select.selectedIndex = 0;
      select.dispatchEvent(new Event("change")); // Trigger change to hide 'between' input
    });
    this.applyFilters();
    this.closeFilterPopup();
  }

  clearAllFilters() {
    this.element
      .querySelectorAll(".table-filters-bar input, .table-filters-bar select")
      .forEach((input) => {
        input.value = "";
        if (input.tagName === "SELECT") input.selectedIndex = 0;
      });
    this.thead
      .querySelectorAll(".filter-control-wrapper")
      .forEach((wrapper) => {
        wrapper.querySelectorAll("input, select").forEach((el) => {
          el.value = el.tagName === "SELECT" ? el.options[0].value : "";
          if (el.tagName === "SELECT") el.dispatchEvent(new Event("change"));
        });
      });
    this.applyFilters();
  }

  /**
   * Builds the final URLSearchParams object for the API request, ensuring
   * filters are nested correctly for PHP to parse.
   */
  _buildApiParams() {
    const params = new URLSearchParams({
      page: this.state.page,
      per_page: this.state.per_page,
      ...this.state.filters.global,
    });

    // This loop creates the filters[users.name][type]=... structure
    for (const column in this.state.filters.advanced) {
      const filter = this.state.filters.advanced[column];
      params.append(`filters[${column}][type]`, filter.type);
      params.append(`filters[${column}][value]`, filter.value);
      if (filter.value2) {
        params.append(`filters[${column}][value2]`, filter.value2);
      }
    }

    if (this.state.sortBy) {
      params.append("sort_by", this.state.sortBy);
      params.append("sort_dir", this.state.sortDir);
    }
    return params;
  }

  async fetchData() {
    this.showLoading();
    const params = this._buildApiParams();
    const url = `${this.config.dataSource.url}?${params.toString()}`;

    try {
      const result = await App.api(url, { method: "GET" }); // Use explicit method
      this.renderTable(result.data.data || result.data);
      if (this.paginationContainer) {
        this.renderPagination(result.data.pagination);
      }
    } catch (error) {
      this.showError(error.message || "Failed to load data.");
    }
  }

  renderTable(data) {
    this.tbody.innerHTML = "";
    if (!data || data.length === 0) {
      this.showEmpty();
      return;
    }
    this.tbody.innerHTML = data
      .map((row) => {
        const cellsHtml = this.config.columns
          .map((col) => {
            // Handle nested keys like 'tenant.name' if necessary in the future
            const value = col.key
              .split(".")
              .reduce((o, i) => (o ? o[i] : undefined), row);
            const renderer =
              DynamicTable.renderers[col.render] ||
              DynamicTable.renderers.default;
            return `<td class="${
              col.align ? `text-${col.align}` : ""
            }">${renderer(value, row)}</td>`;
          })
          .join("");
        return `<tr data-id="${row.id || ""}">${cellsHtml}</tr>`;
      })
      .join("");
  }

  renderPagination(p) {
    if (!p || p.total === 0) {
      this.paginationContainer.innerHTML = "";
      return;
    }
    const from = (p.current_page - 1) * p.per_page + 1;
    const to = Math.min(p.current_page * p.per_page, p.total);

    this.paginationContainer.innerHTML = `
            <div class="table-pagination">
                <div class="pagination-wrapper">
                    <div class="pagination-info">Showing ${from} to ${to} of ${
      p.total
    } results</div>
                    <nav class="pagination-nav">
                        <ul class="flex items-center gap-1">
                            <li><button class="pagination-btn" data-page="${
                              p.current_page - 1
                            }" ${
      p.current_page <= 1 ? "disabled" : ""
    }><ion-icon name="chevron-back-outline" class="w-4 h-4"></ion-icon></button></li>
                            <li><button class="pagination-btn" data-page="${
                              p.current_page + 1
                            }" ${
      p.current_page >= p.last_page ? "disabled" : ""
    }><ion-icon name="chevron-forward-outline" class="w-4 h-4"></ion-icon></button></li>
                        </ul>
                    </nav>
                </div>
            </div>`;
  }

  showLoading() {
    const colspan =
      this.config.columns.length + (this.config.features.selection ? 1 : 0);
    this.tbody.innerHTML = `<tr><td colspan="${colspan}" class="text-center p-8"><div class="loading-spinner"><ion-icon name="reload-outline" class="w-8 h-8 animate-spin text-accent"></ion-icon></div></td></tr>`;
  }

  showError(message) {
    const colspan =
      this.config.columns.length + (this.config.features.selection ? 1 : 0);
    this.tbody.innerHTML = `<tr><td colspan="${colspan}" class="text-center p-8 text-destructive">${App.escapeHTML(
      message
    )}</td></tr>`;
  }

  showEmpty() {
    const colspan =
      this.config.columns.length + (this.config.features.selection ? 1 : 0);
    this.tbody.innerHTML = `<tr><td colspan="${colspan}" class="text-center p-12 text-fg-muted">${
      this.config.emptyMessage || "No records found."
    }</td></tr>`;
  }

  static initAll() {
    document.querySelectorAll("[data-dynamic-table]").forEach((el) => {
      if (!el.dynamicTableInstance) new DynamicTable(el);
    });
  }
}

document.addEventListener("DOMContentLoaded", () => DynamicTable.initAll());
