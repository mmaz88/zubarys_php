// public/assets/js/app.js
window.App = (function (config) {
  "use strict";
  const safeConfig = {
    baseUrl: config.baseUrl || "",
    apiUrl: config.apiUrl || "/api",
  };

  const api = async (endpoint, options = {}) => {
    const url = `${safeConfig.apiUrl}/${endpoint.replace(/^\//, "")}`;
    const defaultHeaders = {
      Accept: "application/json",
      "X-Requested-With": "XMLHttpRequest",
    };
    const fetchConfig = { ...options };
    fetchConfig.headers = { ...defaultHeaders, ...options.headers };
    if (fetchConfig.body) {
      if (fetchConfig.body instanceof FormData) {
        delete fetchConfig.headers["Content-Type"];
      } else if (typeof fetchConfig.body === "object") {
        fetchConfig.body = JSON.stringify(fetchConfig.body);
        fetchConfig.headers["Content-Type"] = "application/json";
      }
    }
    try {
      const response = await fetch(url, fetchConfig);
      const result = await response.json();
      if (!response.ok) {
        const error = new Error(
          result.message || `API Error: ${response.status}`
        );
        error.response = result;
        error.status = response.status;
        throw error;
      }
      return result;
    } catch (error) {
      console.error(`API call to ${endpoint} failed:`, error);
      if (error instanceof SyntaxError) {
        const newError = new Error(
          "The server returned an invalid response. Please check the server logs."
        );
        newError.status = 500;
        throw newError;
      }
      throw error;
    }
  };

  const debounce = (func, delay = 350) => {
    let timeoutId;
    return (...args) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => func.apply(this, args), delay);
    };
  };

  const escapeHTML = (str) => {
    const val = String(str || "");
    return val.replace(
      /[&<>"']/g,
      (m) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#039;",
        }[m])
    );
  };

  const notify = {
    success: (message) =>
      window.AlertSystem.show({
        variant: "success",
        title: "Success",
        message,
      }),
    error: (message) =>
      window.AlertSystem.show({ variant: "danger", title: "Error", message }),
    info: (message) =>
      window.AlertSystem.show({
        variant: "info",
        title: "Information",
        message,
      }),
  };

  const confirm = (options = {}) => {
    const modal = document.getElementById("confirmation-modal");
    if (!modal) {
      console.error("Confirmation modal element not found in the DOM.");
      return Promise.reject(new Error("Modal not found"));
    }
    const titleEl = document.getElementById("confirmation-modal-title");
    const messageEl = document.getElementById("confirmation-modal-message");
    const confirmBtn = document.getElementById("confirmation-modal-confirm");
    const cancelBtn = document.getElementById("confirmation-modal-cancel");

    const config = {
      title: "Confirm Action",
      message: "Are you sure you want to proceed?",
      confirmText: "Confirm",
      confirmVariant: "destructive",
      ...options,
    };

    titleEl.textContent = config.title;
    messageEl.textContent = config.message;
    confirmBtn.textContent = config.confirmText;
    confirmBtn.className = `btn btn-${config.confirmVariant}`;

    modal.classList.remove("hidden");
    setTimeout(() => modal.classList.add("visible"), 10);

    return new Promise((resolve, reject) => {
      let handleEscKey;

      const close = () => {
        modal.classList.remove("visible");
        setTimeout(() => modal.classList.add("hidden"), 200);
        document.removeEventListener("keydown", handleEscKey);
        confirmBtn.removeEventListener("click", onConfirm);
        cancelBtn.removeEventListener("click", onCancel);
      };

      const onConfirm = () => {
        close();
        resolve();
      };
      const onCancel = () => {
        close();
        reject();
      };

      handleEscKey = (event) => {
        if (event.key === "Escape") {
          onCancel();
        }
      };

      document.addEventListener("keydown", handleEscKey);
      confirmBtn.addEventListener("click", onConfirm, { once: true });
      cancelBtn.addEventListener("click", onCancel, { once: true });
    });
  };

  return { api, debounce, escapeHTML, notify, confirm };
})(window.AppConfig || {});
